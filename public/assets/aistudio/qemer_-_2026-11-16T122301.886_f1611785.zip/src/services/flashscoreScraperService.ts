import { Fixture, HistoricalMatch, LeagueCode, FlashscoreScrapedMatch, HeadToHeadMeasurement, HeadToHeadMatchRecord, TeamFormMatch, LeagueStandingTable, LeagueStandingEntry, ProviderStatus, ScrapedMarketOdds } from '../core/types.js';
import { LiveScore } from '../providers/types.js';
import { db } from '../core/db.js';
import { predictionsDb } from '../core/predictionsDb.js';
import { getLeaguePriority } from '../core/leaguePriority.js';

export function convertHistoricalMatchToFixture(m: HistoricalMatch): Fixture {
  const homeScore = m.fthg ?? 0;
  const awayScore = m.ftag ?? 0;

  const stats: Array<{ category: string; homeValue?: any; awayValue?: any }> = [];
  if (m.hs !== undefined && m.asShots !== undefined) {
    stats.push({ category: 'Goal Attempts', homeValue: m.hs, awayValue: m.asShots });
  }
  if (m.hst !== undefined && m.ast !== undefined) {
    stats.push({ category: 'Shots on Goal', homeValue: m.hst, awayValue: m.ast });
  }
  stats.push({ category: 'Goals', homeValue: homeScore, awayValue: awayScore });

  const info = [
    { category: 'Match Date', value: normalizeDateStr(m.matchDate) },
    { category: 'Competition', value: m.leagueName || m.div || 'League' },
    { category: 'Status', value: 'Full Time' },
    { category: 'Result', value: `${homeScore} - ${awayScore}` },
  ];

  return {
    id: m.id ? (m.id.startsWith('hist_') || m.id.startsWith('fs_hist_') ? m.id : `fs_hist_${m.id}`) : `fs_hist_${Math.random()}`,
    providerId: 'FLASHSCORE',
    league: m.div || 'FLASHSCORE',
    leagueName: m.leagueName || m.div || 'FLASHSCORE',
    matchDate: normalizeDateStr(m.matchDate),
    kickOffTime: 'FT',
    homeTeam: m.homeTeam,
    awayTeam: m.awayTeam,
    status: 'FINISHED' as const,
    score: { home: homeScore, away: awayScore },
    statistics: stats,
    information: info,
    prediction: undefined,
  };
}



import { GLOBAL_LEAGUES_DATASET } from '../core/globalLeaguesDataset.js';
import {
  getCurrentSeason,
  getUtcDateStr,
  matchesDateFilter,
  normalizeDateStr,
  normalizeTimeStr,
  getStandardDateStr,
  getStandardTimeStr,
} from '../core/dateUtils.js';
import { loggerService } from './loggerService.js';


const FLASHSCORE_FEED_BASE = 'https://www.flashscore.com/x/feed';
const FLASHSCORE_NINJA_BASE = 'https://2.flashscore.ninja/2/x/feed';
const CYRILLIC_REGEX = /[\u0400-\u04FF]/;
const FSIGN_HEADER = 'SW9D1eZo';
const STATIC_IMAGE_BASE = 'https://static.flashscore.com/res/image/data/';

import {
  parseFeedText,
  parseHeadToHeadFeedText,
  resolveTeamSide,
  resolveFixtureAlignment,
  teamMatchScore,
  H2H_PARSER_VERSION,
  ScrapedRawMatch,
} from '../core/feedParser.js';

export type CircuitState = 'CLOSED' | 'HALF_OPEN' | 'OPEN';

export class ScraperCircuitBreaker {
  private failureCount = 0;
  private successCount = 0;
  private lastFailureTime = 0;
  private state: CircuitState = 'CLOSED';
  private failureThreshold = 5;
  private resetTimeoutMs = 30000;

  public async execute<T>(fn: () => Promise<T>): Promise<T> {
    const now = Date.now();

    if (this.state === 'OPEN') {
      if (now - this.lastFailureTime > this.resetTimeoutMs) {
        this.state = 'HALF_OPEN';
        this.successCount = 0;
      } else {
        throw new Error('Circuit Breaker OPEN - backing off upstream scraper feed requests');
      }
    }

    try {
      const res = await fn();
      this.onSuccess();
      return res;
    } catch (err) {
      this.onFailure();
      throw err;
    }
  }

  private onSuccess() {
    this.failureCount = 0;
    if (this.state === 'HALF_OPEN') {
      this.successCount++;
      if (this.successCount >= 2) {
        this.state = 'CLOSED';
      }
    }
  }

  private onFailure() {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.state = 'OPEN';
    }
  }

  public getStatus(): { state: CircuitState; failureCount: number } {
    return { state: this.state, failureCount: this.failureCount };
  }
}

export const scraperCircuitBreaker = new ScraperCircuitBreaker();

export class FlashscoreScraperService {
  private lastFetchTime = 0;
  private CACHE_TTL_MS = 60000; // 1 minute in-memory cache
  private upcomingMultiDaySyncPromise: Promise<Fixture[]> | null = null;
  private lastMultiDaySyncAt = 0;

  /**
   * Fetch raw feed string from Flashscore feed endpoint
   */
  private async fetchFlashscoreFeed(path: string): Promise<string | null> {
    const urls = [
      `${FLASHSCORE_FEED_BASE}/${path}`,
      `${FLASHSCORE_NINJA_BASE}/${path}`,
      `https://1.flashscore.ninja/2/x/feed/${path}`,
      `https://www.flashscore.co.uk/x/feed/${path}`,
      `https://www.flashscore.in/x/feed/${path}`,
    ];

    let lastError: any = null;

    try {
      return await scraperCircuitBreaker.execute(async () => {
        for (let attempt = 0; attempt < urls.length; attempt++) {
          const url = urls[attempt];
          let timeout: NodeJS.Timeout | null = null;
          try {
            if (attempt > 0) {
              const backoffMs = Math.min(2000, Math.pow(2, attempt - 1) * 300) + Math.random() * 150;
              await new Promise((r) => setTimeout(r, backoffMs));
            }

            const controller = new AbortController();
            timeout = setTimeout(() => controller.abort(), 6000);

            const res = await fetch(url, {
              headers: {
                'x-fsign': FSIGN_HEADER,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                'Referer': 'https://www.flashscore.com/',
                'Origin': 'https://www.flashscore.com',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
              },
              signal: controller.signal,
            });

            if (res.ok) {
              const text = await res.text();
              // Flashscore responses can sometimes be very short (e.g., A1÷¬~)
              if (text && text.length > 0) {
                if (CYRILLIC_REGEX.test(text)) {
                  lastError = new Error(`Non-English (Cyrillic) feed returned by ${url}`);
                  continue;
                }
                return text;
              }
              lastError = new Error(`Flashscore feed response empty on ${url}`);
            } else {
              lastError = new Error(`Flashscore HTTP ${res.status} on ${url}`);
            }
          } catch (err: any) {
            const isAbort = err?.name === 'AbortError' || err?.message?.includes('aborted');
            lastError = isAbort
              ? new Error(`Feed connection timed out (${url})`)
              : (err instanceof Error ? err : new Error(String(err)));
          } finally {
            if (timeout) {
              clearTimeout(timeout);
              timeout = null;
            }
          }
        }
        throw lastError || new Error(`All ${urls.length} Flashscore mirrors failed for path ${path}`);
      });
    } catch (cbErr: any) {
      const localCached = db.getRawFeed(path);
      if (localCached && localCached.rawText && !CYRILLIC_REGEX.test(localCached.rawText)) {
        return localCached.rawText;
      }

      loggerService.addLog({
        level: 'INFO',
        category: 'SCRAPER',
        source: 'FlashscoreScraperService',
        message: `Flashscore feed fallback for path "${path}": ${cbErr?.message || 'Remote endpoints unavailable'}`,
        details: {
          path,
          error: cbErr?.message,
          timestamp: new Date().toISOString(),
        },
      });

      return null;
    }
  }

  async fetchAndPersistRawFeed(path: string, fixtureId?: string): Promise<string | null> {
    const rawText = await this.fetchFlashscoreFeed(path);
    if (rawText) {
      db.saveRawFeed(fixtureId || path, path, rawText);

      // Automatically parse and persist match records from raw feed text into database tables
      try {
        const rawMatches = parseFeedText(rawText);
        if (rawMatches && rawMatches.length > 0) {
          const upcomingFixturesToSave: Fixture[] = [];
          const scrapedMatchesForDb: any[] = [];
          const historicalMatchesToSave: HistoricalMatch[] = [];
          const statusUpdates: Array<{ id: string; status: string; kickOffTime?: string; score?: { home: number; away: number } }> = [];

          for (const m of rawMatches) {
            const matchDateObj = m.timestamp ? new Date(m.timestamp * 1000) : new Date();
            const dateStr = normalizeDateStr(matchDateObj.toISOString().slice(0, 10));
            const hours = String(matchDateObj.getUTCHours()).padStart(2, '0');
            const minutes = String(matchDateObj.getUTCMinutes()).padStart(2, '0');
            const kickOffTime = `${hours}:${minutes}`;

            const { code, name } = this.mapToLeagueCode(m.tournament, m.country);
            const isLive = m.statusCode === '2';
            const isFinished = ['3', '10', '11', '47', '48', '49'].includes(m.statusCode || '');
            const isCancelledOrPostponed = ['4', '5', '6', '36', '37', '38'].includes(m.statusCode || '');
            const mappedStatus = isFinished
              ? 'FINISHED'
              : isLive
              ? 'LIVE'
              : ['5', '36'].includes(m.statusCode || '')
              ? 'CANCELLED'
              : isCancelledOrPostponed
              ? 'POSTPONED'
              : 'SCHEDULED';

            if (isFinished && m.homeScore !== undefined && m.awayScore !== undefined) {
              const ftr = m.homeScore > m.awayScore ? 'H' : m.homeScore < m.awayScore ? 'A' : 'D';
              historicalMatchesToSave.push({
                id: `fs_hist_${m.matchId}`,
                div: code,
                season: getCurrentSeason(),
                matchDate: dateStr,
                homeTeam: m.homeTeam,
                awayTeam: m.awayTeam,
                fthg: m.homeScore,
                ftag: m.awayScore,
                ftr,
              });
              statusUpdates.push({
                id: `fs_${m.matchId}`,
                status: 'FINISHED',
                kickOffTime: 'FT',
                score: { home: m.homeScore, away: m.awayScore },
              });
            } else if (isCancelledOrPostponed) {
              statusUpdates.push({
                id: `fs_${m.matchId}`,
                status: mappedStatus,
                kickOffTime: mappedStatus,
              });
            } else if (!isFinished && !isCancelledOrPostponed) {
              upcomingFixturesToSave.push({
                id: `fs_${m.matchId}`,
                providerId: 'FLASHSCORE',
                league: code,
                leagueName: name,
                matchDate: dateStr,
                kickOffTime,
                timestamp: m.timestamp,
                homeTeam: m.homeTeam,
                awayTeam: m.awayTeam,
                homeBadge: m.homeBadge ? `${STATIC_IMAGE_BASE}${m.homeBadge}` : undefined,
                awayBadge: m.awayBadge ? `${STATIC_IMAGE_BASE}${m.awayBadge}` : undefined,
                status: isLive ? 'LIVE' : 'SCHEDULED',
                stage: m.tournament,
                score: (m.homeScore !== undefined && m.awayScore !== undefined) ? { home: m.homeScore, away: m.awayScore } : undefined,
                minute: m.minute,
                information: [
                  { category: 'Source', value: 'Flashscore Scraping Feed Auto-Parser' },
                  { category: 'Country', value: m.country },
                  { category: 'Competition', value: name },
                ],
                statistics: m.statistics || [],
              });
            }

            scrapedMatchesForDb.push({
              matchId: m.matchId,
              stage: m.tournament,
              status: mappedStatus,
              date: `${dateStr} ${kickOffTime}`,
              country: m.country,
              leagueName: name,
              home: { name: m.homeTeam, image: m.homeBadge ? `${STATIC_IMAGE_BASE}${m.homeBadge}` : undefined },
              away: { name: m.awayTeam, image: m.awayBadge ? `${STATIC_IMAGE_BASE}${m.awayBadge}` : undefined },
              result: {
                home: m.homeScore !== undefined ? String(m.homeScore) : undefined,
                away: m.awayScore !== undefined ? String(m.awayScore) : undefined,
              },
              information: [
                { category: 'Source', value: 'Flashscore Scraping Feed Auto-Parser' },
                { category: 'Country', value: m.country },
                { category: 'Competition', value: name },
              ],
              statistics: m.statistics || [],
            });
          }

          if (upcomingFixturesToSave.length > 0) {
            await db.saveUpcomingFixtures(upcomingFixturesToSave);
          }
          if (statusUpdates.length > 0) {
            db.updateUpcomingFixtureStatuses(statusUpdates);
          }
          if (historicalMatchesToSave.length > 0) {
            db.insertHistoricalMatches(historicalMatchesToSave);
          }
          if (scrapedMatchesForDb.length > 0) {
            db.saveFlashscoreScrapedMatches(scrapedMatchesForDb);
          }
        }
      } catch (parseErr) {
        console.error('[FlashscoreScraper] Error auto-parsing raw feed:', parseErr);
      }
    }
    return rawText;
  }

  /**
   * Map tournament/country string to application LeagueCode
   */
  private mapToLeagueCode(tournament: string, country: string): { code: LeagueCode; name: string } {
    const cleanedTournament = tournament.replace(/^[A-Z\s]+:\s*/, '').trim();
    const cleanedLower = cleanedTournament.toLowerCase();
    const countryLower = (country || '').toLowerCase();

    const matchesCountry = (l: (typeof GLOBAL_LEAGUES_DATASET)[number]) =>
      l.country?.toLowerCase() === countryLower || countryLower === 'international';

    // 1. Exact league name match first (prevents "LaLiga" matching "LaLiga 2" or "Bundesliga" matching "2. Bundesliga")
    const exactMatch = GLOBAL_LEAGUES_DATASET.find(
      (l) => l.name.toLowerCase() === cleanedLower && matchesCountry(l)
    );
    if (exactMatch) {
      return { code: exactMatch.code as LeagueCode, name: exactMatch.name };
    }

    // 2. Fallback to substring match in Global Leagues Dataset
    const match = GLOBAL_LEAGUES_DATASET.find(
      (l) => l.name.toLowerCase().includes(cleanedLower) && matchesCountry(l)
    );

    if (match) {
      return { code: match.code as LeagueCode, name: match.name };
    }

    const countryPrefix = country ? country.trim() : 'International';
    
    // Fallback: Generate native Flashscore naming/slug code
    const nativeCode = `${countryPrefix}_${cleanedTournament}`
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '');

    const name = country ? `${country}: ${cleanedTournament}` : cleanedTournament;
    return { code: nativeCode as LeagueCode, name };
  }


  private hasMultiDayUpcomingCoverage(): boolean {
    if (db.hasCyrillicUpcomingData()) {
      db.purgeCyrillicFixtures();
      return false;
    }
    const day0 = getUtcDateStr(0);
    const day1 = getUtcDateStr(1);
    const day2 = getUtcDateStr(2);
    const counts = db.getUpcomingDateCounts([day0, day1, day2]);
    return (counts[day1] || 0) > 0 && (counts[day2] || 0) > 0;
  }

  public async ensureUpcomingMultiDayCoverage(): Promise<void> {
    if (this.hasMultiDayUpcomingCoverage()) {
      return;
    }
    if (Date.now() - this.lastMultiDaySyncAt < 5 * 60 * 1000 && !this.upcomingMultiDaySyncPromise) {
      return;
    }
    try {
      await this.getUpcomingFixtures(undefined, true);
    } catch {
      // Non-fatal fallback; DB returns whatever is currently stored
    }
  }

  /**
   * Scrapes upcoming and scheduled fixtures from Flashscore UTC feeds across days 0..7
   */
  async getUpcomingFixtures(dateFilter?: string, forceRefresh = false): Promise<Fixture[]> {
    const filterUpper = (dateFilter || '').trim().toUpperCase();
    const isSingleDayFilter = Boolean(dateFilter) && !['ALL', 'NEXT_3_DAYS', 'THIS_WEEK'].includes(filterUpper);

    // 1. Primary lookup: Return cached SQLite fixtures only if multi-day coverage exists (or requested single day is populated)
    if (!forceRefresh) {
      const sqliteUpcoming = db.getUpcomingFixtures(undefined, dateFilter);
      const hasCoverage = isSingleDayFilter
        ? sqliteUpcoming.length > 0
        : sqliteUpcoming.length > 0 && this.hasMultiDayUpcomingCoverage();
      if (hasCoverage) {
        return sqliteUpcoming;
      }
    }

    const runMultiDayScrape = async (): Promise<Fixture[]> => {
      const scrapedFixtures: Fixture[] = [];
      const scrapedMatchesForDb: any[] = [];
      const seenMatchIds = new Set<string>();

      // Scrape Day 0 (today) through Day 7 using canonical UTC feed (t=0)
      const dayOffsets = [0, 1, 2, 3, 4, 5, 6, 7];
      const feedResults: Array<{ feedPath: string; feedText: string | null }> = [];

      const batchSize = 4;
      for (let i = 0; i < dayOffsets.length; i += batchSize) {
        const batch = dayOffsets.slice(i, i + batchSize);
        const batchResults = await Promise.all(
          batch.map(async (offset) => {
            const feedPath = `f_1_${offset}_0_en_1`;
            const feedText = await this.fetchAndPersistRawFeed(feedPath);
            return { feedPath, feedText };
          })
        );
        feedResults.push(...batchResults);
      }

      for (const { feedPath, feedText } of feedResults) {
        if (!feedText) continue;

        const rawMatches = parseFeedText(feedText);

        for (const m of rawMatches) {
          // Skip finished, cancelled, and postponed matches
          if (['3', '4', '5', '6', '10', '11', '36', '37', '38', '47', '48', '49'].includes(m.statusCode || '')) {
            continue;
          }

          // Guarantee unique fixture ID
          if (seenMatchIds.has(m.matchId)) continue;
          seenMatchIds.add(m.matchId);

          const matchDateObj = m.timestamp ? new Date(m.timestamp * 1000) : new Date();
          const dateStr = normalizeDateStr(matchDateObj.toISOString().slice(0, 10));
          const hours = String(matchDateObj.getUTCHours()).padStart(2, '0');
          const minutes = String(matchDateObj.getUTCMinutes()).padStart(2, '0');
          const kickOffTime = `${hours}:${minutes}`;

          const { code, name } = this.mapToLeagueCode(m.tournament, m.country);

          const isLive = m.statusCode === '2';
          const fixture: Fixture = {
            id: `fs_${m.matchId}`,
            providerId: 'FLASHSCORE',
            league: code,
            leagueName: name,
            matchDate: dateStr,
            kickOffTime,
            timestamp: m.timestamp,
            homeTeam: m.homeTeam,
            awayTeam: m.awayTeam,
            homeParticipantId: m.homeParticipantId,
            awayParticipantId: m.awayParticipantId,
            homeBadge: m.homeBadge ? `${STATIC_IMAGE_BASE}${m.homeBadge}` : undefined,
            awayBadge: m.awayBadge ? `${STATIC_IMAGE_BASE}${m.awayBadge}` : undefined,
            status: isLive ? 'LIVE' : 'SCHEDULED',
            stage: m.tournament,
            score: (m.homeScore !== undefined && m.awayScore !== undefined)
              ? { home: m.homeScore, away: m.awayScore }
              : undefined,
            feed_path: feedPath,
            information: [
              { category: 'Source', value: 'Flashscore Scraping Feed' },
              { category: 'Country', value: m.country },
              { category: 'Competition', value: name },
            ],
            statistics: m.statistics || [],
          } as any;

          if (m.statistics && m.statistics.length > 0) {
            db.saveMatchStatistics(m.matchId, m.statistics);
          }

          scrapedFixtures.push(fixture);

          scrapedMatchesForDb.push({
            matchId: m.matchId,
            stage: m.tournament,
            status: isLive ? 'LIVE' : 'SCHEDULED',
            date: `${dateStr} ${kickOffTime}`,
            country: m.country,
            leagueName: name,
            home: {
              name: m.homeTeam,
              image: m.homeBadge ? `${STATIC_IMAGE_BASE}${m.homeBadge}` : undefined,
            },
            away: {
              name: m.awayTeam,
              image: m.awayBadge ? `${STATIC_IMAGE_BASE}${m.awayBadge}` : undefined,
            },
            result: {
              home: m.homeScore !== undefined ? String(m.homeScore) : undefined,
              away: m.awayScore !== undefined ? String(m.awayScore) : undefined,
            },
            information: [
              { category: 'Source', value: 'Flashscore Scraping Feed' },
              { category: 'Country', value: m.country },
              { category: 'Competition', value: name },
            ],
            statistics: m.statistics || [],
          });
        }
      }

      if (scrapedFixtures.length > 0) {
        await db.saveUpcomingFixtures(scrapedFixtures);
        db.saveFlashscoreScrapedMatches(scrapedMatchesForDb);

        loggerService.addLog({
          level: 'SUCCESS',
          category: 'DATA_FETCH',
          source: 'FlashscoreScraper',
          message: `Fetched ${scrapedFixtures.length} upcoming fixtures across days 0..7 from Flashscore UTC feed`,
          details: { count: scrapedFixtures.length, dateFilter: dateFilter || 'All' },
        });

        return scrapedFixtures;
      }

      return db.getUpcomingFixtures();
    };

    if (!this.upcomingMultiDaySyncPromise) {
      this.upcomingMultiDaySyncPromise = runMultiDayScrape().finally(() => {
        this.lastMultiDaySyncAt = Date.now();
        this.upcomingMultiDaySyncPromise = null;
      });
    }

    const allFixtures = await this.upcomingMultiDaySyncPromise;
    if (dateFilter && filterUpper !== 'ALL') {
      return allFixtures.filter((f) => matchesDateFilter(f, dateFilter));
    }
    return allFixtures;
  }

  /**
   * Scrapes live in-play scores from Flashscore
   */
  async getLiveScores(): Promise<LiveScore[]> {
    const feedPath = 'f_1_0_0_en_1';
    const feedText = await this.fetchAndPersistRawFeed(feedPath);
    if (!feedText) {
      // Fallback
      return [];
    }

    const rawMatches = parseFeedText(feedText);
    const seenLiveIds = new Set<string>();
    const liveMatches = rawMatches.filter((m) => {
      if (m.statusCode !== '2') return false;
      if (seenLiveIds.has(m.matchId)) return false;
      seenLiveIds.add(m.matchId);
      return true;
    });

    const liveScores: LiveScore[] = liveMatches.map((m) => {
      let computedMinute = 45;
      let status: LiveScore['status'] = 'FIRST_HALF';

      const nowSec = Math.floor(Date.now() / 1000);
      const startSec = m.timestamp || 0;

      if (m.periodCode === '12') {
        status = 'FIRST_HALF';
        if (startSec > 0) {
          const elapsed = Math.floor((nowSec - startSec) / 60);
          computedMinute = Math.max(1, Math.min(45, elapsed));
        } else {
          computedMinute = 25;
        }
      } else if (m.periodCode === '10' || m.periodCode === '19') {
        computedMinute = 45;
        status = 'HALF_TIME';
      } else if (m.periodCode === '13') {
        status = 'SECOND_HALF';
        if (startSec > 0) {
          const elapsed2 = 45 + Math.floor((nowSec - (startSec + 3600)) / 60);
          computedMinute = Math.max(46, Math.min(90, elapsed2));
        } else {
          computedMinute = 70;
        }
      } else if (m.periodCode === '14') {
        status = 'EXTRA_TIME';
        if (startSec > 0) {
          const elapsedET = 90 + Math.floor((nowSec - (startSec + 6300)) / 60);
          computedMinute = Math.max(91, Math.min(120, elapsedET));
        } else {
          computedMinute = 105;
        }
      } else if (startSec > 0) {
        const elapsed = Math.floor((nowSec - startSec) / 60);
        computedMinute = Math.max(1, Math.min(90, elapsed));
      }

      const finalMinute = (m.minute && m.minute > 0) ? m.minute : computedMinute;
      const { code, name } = this.mapToLeagueCode(m.tournament || '', m.country || '');

      return {
        fixtureId: `fs_${m.matchId}`,
        league: code,
        leagueName: name,
        homeTeam: m.homeTeam,
        awayTeam: m.awayTeam,
        homeScore: m.homeScore ?? 0,
        awayScore: m.awayScore ?? 0,
        minute: finalMinute,
        status,
        events: [],
      };
    });

    return liveScores;
  }


  /**
   * Refreshes and persists daily UTC Flashscore feed (t=0) for a given day offset (-7..1)
   */
  public async syncDailyFeedForOffset(offsetDays: number): Promise<boolean> {
    const clampedOffset = Math.max(-7, Math.min(1, Math.trunc(offsetDays)));
    const feedPath = `f_1_${clampedOffset}_0_en_1`;
    const rawText = await this.fetchAndPersistRawFeed(feedPath);
    return Boolean(rawText && rawText.length > 0);
  }

  /**
   * Queries Flashscore lightweight match header feed (dc_1_<id>) for authoritative status and score.
   * Uses a short timeout and bypasses the global scraperCircuitBreaker so individual lookup misses never block bulk feeds.
   */
  public async fetchMatchStatusAndScore(matchId: string): Promise<{
    statusCode: string;
    status: 'FINISHED' | 'LIVE' | 'SCHEDULED' | 'POSTPONED' | 'CANCELLED';
    homeScore?: number;
    awayScore?: number;
  } | null> {
    const cleanId = String(matchId || '')
      .replace(/^fs_hist_/, '')
      .replace(/^fs_/, '')
      .replace(/^hist_/, '')
      .replace(/^scraped_/, '')
      .trim();

    if (!cleanId) return null;

    const urls = [
      `${FLASHSCORE_FEED_BASE}/dc_1_${cleanId}`,
      `${FLASHSCORE_NINJA_BASE}/dc_1_${cleanId}`,
    ];

    for (const url of urls) {
      let timeout: NodeJS.Timeout | null = null;
      try {
        const controller = new AbortController();
        timeout = setTimeout(() => controller.abort(), 4000);
        const res = await fetch(url, {
          headers: {
            'x-fsign': FSIGN_HEADER,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Referer': 'https://www.flashscore.com/',
            'Origin': 'https://www.flashscore.com',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
          },
          signal: controller.signal,
        });

        if (!res.ok) continue;
        const text = await res.text();
        if (!text || (!text.includes('DB÷') && !text.includes('DA÷') && !text.includes('DE÷'))) {
          continue;
        }

        const kv: Record<string, string> = {};
        for (const section of text.split('~')) {
          for (const part of section.split('¬')) {
            const sepIdx = part.indexOf('÷');
            if (sepIdx > 0) {
              kv[part.slice(0, sepIdx)] = part.slice(sepIdx + 1);
            }
          }
        }

        const statusCode = kv['DB'] || kv['DA'] || kv['DZ'] || '';
        const parsedHome = kv['DE'] !== undefined && kv['DE'] !== '' ? parseInt(kv['DE'], 10) : NaN;
        const parsedAway = kv['DF'] !== undefined && kv['DF'] !== '' ? parseInt(kv['DF'], 10) : NaN;
        const homeScore = Number.isFinite(parsedHome) ? parsedHome : undefined;
        const awayScore = Number.isFinite(parsedAway) ? parsedAway : undefined;

        let status: 'FINISHED' | 'LIVE' | 'SCHEDULED' | 'POSTPONED' | 'CANCELLED' = 'SCHEDULED';
        if (['3', '10', '11', '47', '48', '49'].includes(statusCode)) {
          status = 'FINISHED';
        } else if (statusCode === '2') {
          status = 'LIVE';
        } else if (['5', '36'].includes(statusCode)) {
          status = 'CANCELLED';
        } else if (['4', '6', '37', '38'].includes(statusCode)) {
          status = 'POSTPONED';
        }

        return { statusCode, status, homeScore, awayScore };
      } catch {
        // Try next mirror
      } finally {
        if (timeout) {
          clearTimeout(timeout);
          timeout = null;
        }
      }
    }

    return null;
  }

  /**
   * Clears in-memory caches for fresh scraping
   */
  public clearCaches(): void {
    this.lastFetchTime = 0;
    this.lastMultiDaySyncAt = 0;
  }

  /**
   * Playwright headless browser fallback when direct HTTP feed requests fail or hit Cloudflare/403/429
   */
  private async runPlaywrightScraperFallback(seasonUrl: string): Promise<HistoricalMatch[]> {
    loggerService.addLog({
      level: 'INFO',
      category: 'SCRAPER',
      source: 'FlashscoreScraperService',
      message: `Executing Playwright headless browser fallback for URL: ${seasonUrl}`,
    });

    const matches: HistoricalMatch[] = [];
    try {
      // Dynamic import of playwright via indirect evaluation so Vite dev server AST scanner does not try to bundle browser/Node playwright dependencies
      // @ts-ignore
      const pwImport = new Function('m', 'return import(m)');
      const { chromium } = await pwImport('playwright');
      if (!chromium) return matches;
      
      const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }).catch(() => null);
      if (!browser) return matches;

      const context = await browser.newContext({
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      }).catch(() => null);
      if (!context) {
        await browser.close().catch(() => {});
        return matches;
      }

      const page = await context.newPage().catch(() => null);
      if (!page) {
        await browser.close().catch(() => {});
        return matches;
      }

      await page.goto(seasonUrl, { waitUntil: 'domcontentloaded', timeout: 8000 }).catch(() => {});

      // Click "Show more matches" if available
      const loadMoreSelector = '[data-testid="wcl-buttonLink"]';
      for (let i = 0; i < 3; i++) {
        try {
          const btn = await page.$(loadMoreSelector);
          if (!btn) break;
          await btn.click();
          await page.waitForTimeout(400);
        } catch {
          break;
        }
      }

      // Extract match elements from DOM
      const rawDOMMatches = await page.evaluate(() => {
        const els = Array.from(document.querySelectorAll('.event__match.event__match--static.event__match--twoLine'));
        return els.map((el) => {
          const id = el.id ? el.id.replace('g_1_', '') : '';
          const home = el.querySelector('.event__participant--home')?.textContent?.trim() || '';
          const away = el.querySelector('.event__participant--away')?.textContent?.trim() || '';
          const scoreHome = el.querySelector('.event__score--home')?.textContent?.trim() || '';
          const scoreAway = el.querySelector('.event__score--away')?.textContent?.trim() || '';
          return { id, home, away, scoreHome, scoreAway };
        });
      }).catch(() => []);

      await browser.close().catch(() => {});

      for (const m of rawDOMMatches) {
        if (!m.id || !m.home || !m.away) continue;
        const hScore = parseInt(m.scoreHome, 10);
        const aScore = parseInt(m.scoreAway, 10);
        if (isNaN(hScore) || isNaN(aScore)) continue;

        const ftr = hScore > aScore ? 'H' : hScore < aScore ? 'A' : 'D';
        matches.push({
          id: `fs_hist_${m.id}`,
          div: 'FLASHSCORE',
          season: getCurrentSeason(),
          matchDate: normalizeDateStr(getStandardDateStr(new Date())),
          homeTeam: m.home,
          awayTeam: m.away,
          fthg: hScore,
          ftag: aScore,
          ftr,
        });
      }

      if (matches.length > 0) {
        loggerService.addLog({
          level: 'SUCCESS',
          category: 'SCRAPER',
          source: 'FlashscoreScraperService',
          message: `Playwright headless fallback successfully retrieved ${matches.length} matches from ${seasonUrl}`,
        });
      }
    } catch (err: any) {
      loggerService.addLog({
        level: 'WARN',
        category: 'SCRAPER',
        source: 'FlashscoreScraperService',
        message: `Playwright headless fallback skipped for ${seasonUrl}: ${err?.message || err}`,
      });
    }

    return matches;
  }

  /**
   * Discovers and scrapes full multi-year season archive results for a given tournament path
   */
  async scrapeLeagueArchive(
    baseLeaguePath: string,
    leagueCode: string,
    maxSeasons = 2,
    allowPlaywrightFallback = false
  ): Promise<HistoricalMatch[]> {
    const historicalMatches: HistoricalMatch[] = [];
    const seenMatchIds = new Set<string>();

    try {
      // 1. Fetch the /archive/ page to discover past season URLs
      const archiveUrl = `https://www.flashscore.com${baseLeaguePath.replace(/\/results\/?$/, '')}/archive/`;
      let seasonUrls: string[] = [`https://www.flashscore.com${baseLeaguePath}`];

      let archiveTimeout: ReturnType<typeof setTimeout> | null = null;
      try {
        const controller = new AbortController();
        archiveTimeout = setTimeout(() => controller.abort(), 4000);
        const res = await fetch(archiveUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          },
          signal: controller.signal,
        });

        if (res.ok) {
          const html = await res.text();
          const seasonMatches = Array.from(html.matchAll(/href=["'](\/football\/[a-z0-9-]+\/[a-z0-9-]+-[0-9]{4}-[0-9]{4}\/results\/)["']/g));
          const extractedUrls = Array.from(new Set(seasonMatches.map((m) => `https://www.flashscore.com${m[1]}`)));
          if (extractedUrls.length > 0) {
            seasonUrls = [...seasonUrls, ...extractedUrls].slice(0, maxSeasons);
          }
        }
      } catch (err) {
        loggerService.addLog({
          level: 'INFO',
          category: 'SCRAPER',
          source: 'FlashscoreScraperService',
          message: `Archive listing fetch note for ${leagueCode}: ${err}`,
        });
      } finally {
        if (archiveTimeout) clearTimeout(archiveTimeout);
      }

      // 2. Scrape results for each discovered season
      for (const seasonUrl of seasonUrls) {
        let seasonMatchesExtracted = 0;
        let seasonTimeout: ReturnType<typeof setTimeout> | null = null;
        try {
          const controller = new AbortController();
          seasonTimeout = setTimeout(() => controller.abort(), 4000);
          const res = await fetch(seasonUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            },
            signal: controller.signal,
          });

          if (res.ok) {
            const html = await res.text();
            const resultsMatch = html.match(/cjs\.initialFeeds\[['"](?:summary-)?results['"]\]\s*=\s*\{\s*data:\s*[`"']([\s\S]*?)[`"']\s*\}/);

            if (resultsMatch && resultsMatch[1]) {
              const sections = resultsMatch[1].split('~');
              for (const s of sections) {
                if (!s.startsWith('AA÷')) continue;
                const parts = s.split('¬');
                const data: Record<string, string> = {};
                for (const p of parts) {
                  const [k, v] = p.split('÷');
                  if (k && v !== undefined) data[k] = v;
                }
                const matchId = data['AA'];
                if (!matchId || seenMatchIds.has(matchId)) continue;
                if (data['AB'] !== '3' || data['AG'] === undefined || data['AH'] === undefined) continue;

                const homeTeam = (data['AE'] || '').trim();
                const awayTeam = (data['AF'] || '').trim();
                const homeScore = parseInt(data['AG'], 10);
                const awayScore = parseInt(data['AH'], 10);
                if (!homeTeam || !awayTeam || isNaN(homeScore) || isNaN(awayScore)) continue;

                seenMatchIds.add(matchId);
                const ts = parseInt(data['AD'] || '0', 10);
                const matchDateObj = ts ? new Date(ts * 1000) : new Date();
                const matchDate = normalizeDateStr(getStandardDateStr(matchDateObj));
                const ftr = homeScore > awayScore ? 'H' : homeScore < awayScore ? 'A' : 'D';

                historicalMatches.push({
                  id: `fs_hist_${matchId}`,
                  div: leagueCode,
                  season: getCurrentSeason(),
                  matchDate,
                  homeTeam,
                  awayTeam,
                  fthg: homeScore,
                  ftag: awayScore,
                  ftr,
                });
                seasonMatchesExtracted++;
              }
            }
          }
        } catch (err) {
          if (allowPlaywrightFallback) {
            const fallbackResults = await this.runPlaywrightScraperFallback(seasonUrl);
            for (const fm of fallbackResults) {
              if (!seenMatchIds.has(fm.id)) {
                seenMatchIds.add(fm.id);
                historicalMatches.push({ ...fm, div: leagueCode });
              }
            }
          }
        } finally {
          if (seasonTimeout) clearTimeout(seasonTimeout);
        }

        if (allowPlaywrightFallback && seasonMatchesExtracted === 0) {
          const fallbackResults = await this.runPlaywrightScraperFallback(seasonUrl);
          for (const fm of fallbackResults) {
            if (!seenMatchIds.has(fm.id)) {
              seenMatchIds.add(fm.id);
              historicalMatches.push({ ...fm, div: leagueCode });
            }
          }
        }
      }
    } catch (err: any) {
      loggerService.addLog({
        level: 'WARN',
        category: 'SCRAPER',
        source: 'FlashscoreScraperService',
        message: `Skipped archive scrape for ${leagueCode}: ${err?.message || err}`,
      });
    }

    return historicalMatches;
  }

  /**
   * Scrapes completed match results from Flashscore to populate historical database
   */
  async syncHistoricalData(
    daysBack = 7,
    _shouldClear = false,
    options?: { skipUpcomingRefresh?: boolean }
  ): Promise<{ success: boolean; matchesCount: number; message: string }> {
    loggerService.addLog({
      level: 'INFO',
      category: 'SCRAPER',
      source: 'FlashscoreScraperService',
      message: `Starting syncHistoricalData with multi-year archive crawling (daysBack: ${daysBack})`,
    });

    let inserted = 0;
    // Scrape past days down to -7 (Flashscore maximum historical feed range)
    const effectiveDays = Math.min(Math.abs(daysBack), 7);
    const historyDayOffsets: number[] = [];
    for (let d = -effectiveDays; d <= 0; d++) {
      historyDayOffsets.push(d);
    }
    const historicalMatches: HistoricalMatch[] = [];
    const seenHistIds = new Set<string>();

    for (const offset of historyDayOffsets) {
      const feedPath = `f_1_${offset}_3_en_1`;
      const feedText = await this.fetchAndPersistRawFeed(feedPath);
      if (!feedText) continue;

      const rawMatches = parseFeedText(feedText);
      const finished = rawMatches.filter((m) =>
        m.homeScore !== undefined &&
        m.awayScore !== undefined &&
        (['3', '10', '11', '47', '48', '49'].includes(m.statusCode || '') || (offset < 0 && m.statusCode !== '1' && m.statusCode !== '2'))
      );

      for (const m of finished) {
        if (seenHistIds.has(m.matchId)) continue;
        seenHistIds.add(m.matchId);
        const { code } = this.mapToLeagueCode(m.tournament, m.country);
        const matchDateObj = m.timestamp ? new Date(m.timestamp * 1000) : new Date();
        const dateStr = normalizeDateStr(getStandardDateStr(matchDateObj));

        const homeScore = m.homeScore!;
        const awayScore = m.awayScore!;
        const ftr = homeScore > awayScore ? 'H' : homeScore < awayScore ? 'A' : 'D';

        // Extract shots from statistics
        let hs, asShots, hst, ast;
        if (m.statistics) {
          const shots = m.statistics.find((s: any) => s.category.toLowerCase().includes('shots'));
          if (shots) {
            const h = shots.homeValue?.split('-') || [];
            const a = shots.awayValue?.split('-') || [];
            hs = parseInt(h[0], 10);
            asShots = parseInt(a[0], 10);
            hst = parseInt(h[1], 10);
            ast = parseInt(a[1], 10);
          }
        }

        historicalMatches.push({
          id: `fs_hist_${m.matchId}`,
          div: code,
          season: getCurrentSeason(),
          matchDate: dateStr,
          homeTeam: m.homeTeam,
          awayTeam: m.awayTeam,
          fthg: homeScore,
          ftag: awayScore,
          ftr,
          hs,
          asShots,
          hst,
          ast,
        });
      }
    }

    // Expanded multi-year completed season results for the last 3 complete seasons across global leagues
    const tournamentPages = [
      { path: '/football/england/premier-league/results/', code: 'england_premier_league' },
      { path: '/football/spain/laliga/results/', code: 'spain_la_liga' },
      { path: '/football/germany/bundesliga/results/', code: 'germany_bundesliga' },
      { path: '/football/italy/serie-a/results/', code: 'italy_serie_a' },
      { path: '/football/france/ligue-1/results/', code: 'france_ligue_1' },
      { path: '/football/europe/champions-league/results/', code: 'europe_champions_league_league_phase' },
      { path: '/football/europe/europa-league/results/', code: 'europe_europa_league_league_phase' },
      { path: '/football/england/championship/results/', code: 'england_championship' },
      { path: '/football/netherlands/eredivisie/results/', code: 'netherlands_eredivisie' },
      { path: '/football/portugal/liga-portugal/results/', code: 'portugal_primeira_liga' },
      { path: '/football/brazil/serie-a/results/', code: 'brazil_serie_a' },
      { path: '/football/usa/mls/results/', code: 'usa_major_league_soccer' },
      { path: '/football/germany/2-bundesliga/results/', code: 'germany_2_bundesliga' },
      { path: '/football/france/ligue-2/results/', code: 'france_ligue_2' },
      { path: '/football/italy/serie-b/results/', code: 'italy_serie_b' },
      { path: '/football/spain/laliga2/results/', code: 'spain_la_liga_2' },
      { path: '/football/turkey/super-lig/results/', code: 'turkey_super_lig' },
      { path: '/football/belgium/jupiler-pro-league/results/', code: 'belgium_jupiler_pro_league' },
      { path: '/football/scotland/premiership/results/', code: 'scotland_premiership' },
      { path: '/football/austria/bundesliga/results/', code: 'austria_bundesliga' },
      { path: '/football/switzerland/super-league/results/', code: 'switzerland_super_league' },
      { path: '/football/denmark/superliga/results/', code: 'denmark_superliga' },
      { path: '/football/norway/eliteserien/results/', code: 'norway_eliteserien' },
      { path: '/football/sweden/allsvenskan/results/', code: 'sweden_allsvenskan' },
      { path: '/football/greece/super-league/results/', code: 'greece_super_league' },
      { path: '/football/poland/ekstraklasa/results/', code: 'poland_ekstraklasa' },
      { path: '/football/mexico/liga-mx/results/', code: 'mexico_liga_mx' },
      { path: '/football/argentina/liga-profesional/results/', code: 'argentina_liga_profesional' },
      { path: '/football/japan/j1-league/results/', code: 'japan_j1_league' },
      { path: '/football/south-korea/k-league-1/results/', code: 'south_korea_k_league_1' },
      { path: '/football/saudi-arabia/saudi-professional-league/results/', code: 'saudi_arabia_saudi_professional_league' },
    ];

    const archiveBatchSize = 5;
    for (let i = 0; i < tournamentPages.length; i += archiveBatchSize) {
      const batch = tournamentPages.slice(i, i + archiveBatchSize);
      await Promise.allSettled(
        batch.map(async (t) => {
          const archivedMatches = await this.scrapeLeagueArchive(t.path, t.code, 3, false);
          for (const am of archivedMatches) {
            if (!seenHistIds.has(am.id)) {
              seenHistIds.add(am.id);
              historicalMatches.push(am);
            }
          }
        })
      );
    }

    if (historicalMatches.length > 0) {
      inserted = db.insertHistoricalMatches(historicalMatches);
    }

    // Refresh upcoming fixtures across all multi-day feeds (unless Step 4 will execute it immediately after)
    const upcoming = options?.skipUpcomingRefresh
      ? []
      : await this.getUpcomingFixtures(undefined, true);

    // Scrape and save standings into SQLite database table during fullsync process
    const popularLeagues = [
      'england_premier_league',
      'spain_la_liga',
      'germany_bundesliga',
      'italy_serie_a',
      'france_ligue_1',
      'europe_champions_league_league_phase',
      'europe_europa_league_league_phase',
      'england_championship',
      'netherlands_eredivisie',
      'portugal_primeira_liga',
      'brazil_serie_a',
      'usa_major_league_soccer',
      'germany_2_bundesliga',
      'france_ligue_2',
      'italy_serie_b',
      'spain_la_liga_2',
      'turkey_super_lig',
      'belgium_jupiler_pro_league',
      'scotland_premiership',
      'austria_bundesliga',
      'switzerland_super_league',
      'denmark_superliga',
      'norway_eliteserien',
      'sweden_allsvenskan',
      'greece_super_league',
      'poland_ekstraklasa',
      'mexico_liga_mx',
      'argentina_liga_profesional',
      'japan_j1_league',
      'south_korea_k_league_1',
      'saudi_arabia_saudi_professional_league',
    ];
    const standingsBatchSize = 4;
    for (let i = 0; i < popularLeagues.length; i += standingsBatchSize) {
      const batch = popularLeagues.slice(i, i + standingsBatchSize);
      await Promise.allSettled(batch.map((code) => this.fetchAndSaveLeagueStandings(code)));
    }

    return {
      success: true,
      matchesCount: historicalMatches.length + upcoming.length,
      message: `FlashscoreScraping synchronized ${historicalMatches.length} real historical multi-year results, ${upcoming.length} upcoming fixtures, and league standings into database.`,
    };
  }

  /**
   * Match detail extraction matching gustavofariaa/FlashscoreScraping schema
   */
  async getMatchData(matchId: string): Promise<FlashscoreScrapedMatch | null> {
    const cleanId = matchId.replace(/^fs_/, '').replace(/^hist_/, '').trim();
    const matches = db.getFlashscoreScrapedMatches(1000);
    const existing = matches.find((m) => m.matchId === matchId || m.matchId === cleanId || `fs_${m.matchId}` === matchId);
    if (existing) {
      return existing;
    }

    // Try parsing directly from raw feed in DB
    const rawFeed = db.getRawFeed(cleanId);
    if (rawFeed && rawFeed.rawText) {
      const parsedMatches = parseFeedText(rawFeed.rawText);
      const m = parsedMatches.find((pm) => pm.matchId === cleanId);
      if (m) {
        const { name } = this.mapToLeagueCode(m.tournament, m.country);
        const matchObj: FlashscoreScrapedMatch = {
          matchId: m.matchId,
          stage: m.tournament,
          status: m.statusCode === '3' ? 'FINISHED' : m.statusCode === '2' ? 'LIVE' : 'SCHEDULED',
          date: m.timestamp ? new Date(m.timestamp * 1000).toISOString() : '',
          country: m.country,
          leagueName: name,
          home: {
            name: m.homeTeam,
            image: m.homeBadge ? `${STATIC_IMAGE_BASE}${m.homeBadge}` : undefined,
          },
          away: {
            name: m.awayTeam,
            image: m.awayBadge ? `${STATIC_IMAGE_BASE}${m.awayBadge}` : undefined,
          },
          result: {
            home: m.homeScore !== undefined ? String(m.homeScore) : undefined,
            away: m.awayScore !== undefined ? String(m.awayScore) : undefined,
          },
          information: [
            { category: 'Source', value: 'Flashscore Scraping Raw Feed' },
            { category: 'Country', value: m.country },
            { category: 'Competition', value: name },
          ],
          statistics: m.statistics || [],
        };
        db.saveFlashscoreScrapedMatches([matchObj]);
        return matchObj;
      }
    }

    return null;
  }

  /**
   * Improvement 2: Intelligent HTML Match Page Scraper Fallback
   * Fetches Flashscore match HTML page and parses meta/OG tags when API feeds time out or block.
   */
  async fetchMatchHtmlFallback(matchId: string): Promise<{
    status: 'FINISHED' | 'LIVE' | 'SCHEDULED' | 'POSTPONED' | 'CANCELLED';
    homeScore?: number;
    awayScore?: number;
  } | null> {
    const cleanId = String(matchId || '').replace(/^fs_/, '').replace(/^hist_/, '').trim();
    if (!cleanId) return null;

    const urls = [
      `https://www.flashscore.com/match/${cleanId}/`,
      `https://www.flashscore.in/match/${cleanId}/`,
    ];

    for (const url of urls) {
      let timeout: ReturnType<typeof setTimeout> | null = null;
      try {
        const controller = new AbortController();
        timeout = setTimeout(() => controller.abort(), 5000);
        const res = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Referer': 'https://www.flashscore.com/',
            'Accept': 'text/html,application/xhtml+xml',
          },
          signal: controller.signal,
        });

        if (!res.ok) continue;
        const html = await res.text();
        if (!html || html.length < 100) continue;

        // Parse score from title or OG description (e.g., "2:1", "1 - 0")
        const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
        const titleText = titleMatch ? titleMatch[1] : '';
        const scoreRegex = /(\d+)\s*[:\x2D]\s*(\d+)/;
        const matchScore = titleText.match(scoreRegex);

        if (matchScore) {
          const homeScore = parseInt(matchScore[1], 10);
          const awayScore = parseInt(matchScore[2], 10);
          if (!isNaN(homeScore) && !isNaN(awayScore)) {
            const isFinished = titleText.toLowerCase().includes('full time') || titleText.toLowerCase().includes('ft') || html.includes('Finished');
            return {
              status: isFinished ? 'FINISHED' : 'LIVE',
              homeScore,
              awayScore,
            };
          }
        }
      } catch {} finally {
        if (timeout) clearTimeout(timeout);
      }
    }
    return null;
  }

  /**
   * Scrapes live Flashscore bookmaker odds across 1X2, Double Chance, Over/Under, BTTS, and Correct Score
   * via Flashscore's odds GraphQL endpoint, computes vig-removed market-implied probabilities,
   * and persists results in SQLite (match_odds_cache & upcoming_fixtures).
   */
  async fetchMatchOdds(
    matchId: string,
    options?: {
      homeParticipantId?: string;
      awayParticipantId?: string;
      forceRefresh?: boolean;
      skipDbSave?: boolean;
    }
  ): Promise<ScrapedMarketOdds | null> {
    const cleanId = String(matchId || '').replace(/^fs_/, '').replace(/^hist_/, '').trim();
    if (!cleanId) return null;

    if (!options?.forceRefresh) {
      const cached = db.getMatchOddsCache(cleanId);
      if (cached && cached.homeOdds && cached.awayOdds) {
        return cached;
      }
    }

    const avg = (arr: number[]): number | undefined => {
      if (!arr || arr.length === 0) return undefined;
      const sum = arr.reduce((a, b) => a + b, 0);
      return Number((sum / arr.length).toFixed(2));
    };

    const removeVig2Way = (o1?: number, o2?: number): [number | undefined, number | undefined] => {
      if (!o1 || !o2 || o1 <= 1 || o2 <= 1) return [undefined, undefined];
      const p1 = 1 / o1;
      const p2 = 1 / o2;
      const tot = p1 + p2;
      return [Number((p1 / tot).toFixed(4)), Number((p2 / tot).toFixed(4))];
    };

    const removeVig3Way = (o1?: number, o2?: number, o3?: number): [number | undefined, number | undefined, number | undefined] => {
      if (!o1 || !o2 || !o3 || o1 <= 1 || o2 <= 1 || o3 <= 1) return [undefined, undefined, undefined];
      const p1 = 1 / o1;
      const p2 = 1 / o2;
      const p3 = 1 / o3;
      const tot = p1 + p2 + p3;
      return [
        Number((p1 / tot).toFixed(4)),
        Number((p2 / tot).toFixed(4)),
        Number((p3 / tot).toFixed(4)),
      ];
    };

    let timeout: ReturnType<typeof setTimeout> | null = null;
    try {
      const controller = new AbortController();
      timeout = setTimeout(() => controller.abort(), 5000);
      const urls = [
        `https://global.ds.lsapp.eu/odds/pq_graphql?_hash=oce&eventId=${encodeURIComponent(cleanId)}&projectId=2&geoIpCode=GB&geoIpSubdivisionCode=`,
        `https://global.ds.lsapp.eu/odds/pq_graphql?_hash=oce&eventId=${encodeURIComponent(cleanId)}&projectId=2&geoIpCode=US&geoIpSubdivisionCode=USNY`,
      ];

      let oddsEntries: any[] | null = null;
      for (const url of urls) {
        const res = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Origin': 'https://www.flashscore.com',
            'Referer': 'https://www.flashscore.com/',
            'Accept': 'application/json',
          },
          signal: controller.signal,
        });
        if (!res.ok) continue;
        const json = (await res.json()) as any;
        const entries = json?.data?.findOddsByEventId?.odds;
        if (Array.isArray(entries) && entries.length > 0) {
          oddsEntries = entries;
          break;
        }
      }

      if (!Array.isArray(oddsEntries) || oddsEntries.length === 0) return null;

      let homePid = options?.homeParticipantId;
      let awayPid = options?.awayParticipantId;

      if (!homePid || !awayPid) {
        const rawPids = db.getFixtureParticipantIds(cleanId);
        if (rawPids) {
          homePid = homePid || rawPids.homeParticipantId;
          awayPid = awayPid || rawPids.awayParticipantId;
        }
      }

      const fullTime1X2Entries = oddsEntries.filter(
        (o: any) => o.bettingType === 'HOME_DRAW_AWAY' && o.bettingScope === 'FULL_TIME' && Array.isArray(o.odds)
      );

      // Infer participant IDs cleanly from HOME_DRAW_AWAY FULL_TIME order [Home, Away, Draw] only if JA/JB unavailable
      if (!homePid || !awayPid) {
        for (const entry of fullTime1X2Entries) {
          const nonNullPids = entry.odds
            .map((item: any) => item?.eventParticipantId)
            .filter((pid: any) => typeof pid === 'string' && pid.length > 0);
          if (nonNullPids.length >= 2) {
            homePid = homePid || nonNullPids[0];
            awayPid = awayPid || nonNullPids[1];
            break;
          }
        }
      }

      const bookmakerIds = new Set<number>();
      const h1Arr: number[] = [];
      const dXArr: number[] = [];
      const a2Arr: number[] = [];
      const dc1XArr: number[] = [];
      const dc12Arr: number[] = [];
      const dcX2Arr: number[] = [];
      const o15Arr: number[] = [];
      const u15Arr: number[] = [];
      const o25Arr: number[] = [];
      const u25Arr: number[] = [];
      const o35Arr: number[] = [];
      const u35Arr: number[] = [];
      const bttsYesArr: number[] = [];
      const bttsNoArr: number[] = [];
      const csMap = new Map<string, number[]>();

      for (const entry of oddsEntries) {
        if (entry?.bettingScope !== 'FULL_TIME' || !Array.isArray(entry.odds)) continue;
        if (typeof entry.bookmakerId === 'number') {
          bookmakerIds.add(entry.bookmakerId);
        }

        if (entry.bettingType === 'HOME_DRAW_AWAY') {
          for (const item of entry.odds) {
            const val = parseFloat(item?.value);
            if (!Number.isFinite(val) || val <= 1.01) continue;
            if (item.eventParticipantId === null || item.eventParticipantId === undefined) {
              dXArr.push(val);
            } else if (homePid && item.eventParticipantId === homePid) {
              h1Arr.push(val);
            } else if (awayPid && item.eventParticipantId === awayPid) {
              a2Arr.push(val);
            }
          }
        } else if (entry.bettingType === 'DOUBLE_CHANCE') {
          for (const item of entry.odds) {
            const val = parseFloat(item?.value);
            if (!Number.isFinite(val) || val <= 1.01) continue;
            if (item.eventParticipantId === null || item.eventParticipantId === undefined) {
              dc12Arr.push(val);
            } else if (homePid && item.eventParticipantId === homePid) {
              dc1XArr.push(val);
            } else if (awayPid && item.eventParticipantId === awayPid) {
              dcX2Arr.push(val);
            }
          }
        } else if (entry.bettingType === 'OVER_UNDER') {
          for (const item of entry.odds) {
            const val = parseFloat(item?.value);
            const hcap = String(item?.handicap?.value || '').trim();
            const sel = String(item?.selection || '').toUpperCase();
            if (!Number.isFinite(val) || val <= 1.01) continue;
            if (hcap === '1.5') {
              if (sel === 'OVER') o15Arr.push(val);
              else if (sel === 'UNDER') u15Arr.push(val);
            } else if (hcap === '2.5') {
              if (sel === 'OVER') o25Arr.push(val);
              else if (sel === 'UNDER') u25Arr.push(val);
            } else if (hcap === '3.5') {
              if (sel === 'OVER') o35Arr.push(val);
              else if (sel === 'UNDER') u35Arr.push(val);
            }
          }
        } else if (entry.bettingType === 'BOTH_TEAMS_TO_SCORE') {
          for (const item of entry.odds) {
            const val = parseFloat(item?.value);
            if (!Number.isFinite(val) || val <= 1.01) continue;
            if (item.bothTeamsToScore === true) bttsYesArr.push(val);
            else if (item.bothTeamsToScore === false) bttsNoArr.push(val);
          }
        } else if (entry.bettingType === 'CORRECT_SCORE') {
          for (const item of entry.odds) {
            const val = parseFloat(item?.value);
            const rawScore = String(item?.score || '').trim();
            if (!Number.isFinite(val) || val <= 1.01 || !rawScore) continue;
            const normScore = rawScore.replace(':', '-');
            const list = csMap.get(normScore) || [];
            list.push(val);
            csMap.set(normScore, list);
          }
        }
      }

      const homeOdds = avg(h1Arr);
      const drawOdds = avg(dXArr);
      const awayOdds = avg(a2Arr);
      const [homeImpliedProb, drawImpliedProb, awayImpliedProb] = removeVig3Way(homeOdds, drawOdds, awayOdds);

      const dc1XOdds = avg(dc1XArr);
      const dc12Odds = avg(dc12Arr);
      const dcX2Odds = avg(dcX2Arr);
      // 1X implied = (Home + Draw), X2 implied = (Draw + Away) when 1X2 exists, else vig-adjusted reciprocal
      const dc1XImpliedProb =
        homeImpliedProb !== undefined && drawImpliedProb !== undefined
          ? Number(Math.min(0.99, homeImpliedProb + drawImpliedProb).toFixed(4))
          : dc1XOdds && dc1XOdds > 1
          ? Number(Math.min(0.99, (1 / dc1XOdds) * 0.94).toFixed(4))
          : undefined;
      const dcX2ImpliedProb =
        awayImpliedProb !== undefined && drawImpliedProb !== undefined
          ? Number(Math.min(0.99, awayImpliedProb + drawImpliedProb).toFixed(4))
          : dcX2Odds && dcX2Odds > 1
          ? Number(Math.min(0.99, (1 / dcX2Odds) * 0.94).toFixed(4))
          : undefined;

      const over15Odds = avg(o15Arr);
      const under15Odds = avg(u15Arr);
      const [over15ImpliedProb] = removeVig2Way(over15Odds, under15Odds);

      const over25Odds = avg(o25Arr);
      const under25Odds = avg(u25Arr);
      const [over25ImpliedProb, under25ImpliedProb] = removeVig2Way(over25Odds, under25Odds);

      const over35Odds = avg(o35Arr);
      const under35Odds = avg(u35Arr);
      const [over35ImpliedProb] = removeVig2Way(over35Odds, under35Odds);

      const bttsYesOdds = avg(bttsYesArr);
      const bttsNoOdds = avg(bttsNoArr);
      const [bttsYesImpliedProb, bttsNoImpliedProb] = removeVig2Way(bttsYesOdds, bttsNoOdds);

      const allCs = Array.from(csMap.entries())
        .map(([score, vals]) => {
          const o = avg(vals)!;
          return { score, odds: o, rawProb: 1 / o };
        })
        .sort((a, b) => a.odds - b.odds);
      const csOverround = allCs.reduce((sum, x) => sum + x.rawProb, 0) || 1;
      const topCorrectScores = allCs.slice(0, 5).map((x) => ({
        score: x.score,
        odds: x.odds,
        impliedProb: Number((x.rawProb / csOverround).toFixed(4)),
      }));

      if (
        homeOdds === undefined &&
        awayOdds === undefined &&
        over25Odds === undefined &&
        bttsYesOdds === undefined
      ) {
        return null;
      }

      const result: ScrapedMarketOdds = {
        provider: 'FLASHSCORE',
        fetchedAt: new Date().toISOString(),
        bookmakersCount: bookmakerIds.size > 0 ? bookmakerIds.size : undefined,
        homeParticipantId: homePid,
        awayParticipantId: awayPid,
        homeOdds,
        drawOdds,
        awayOdds,
        homeImpliedProb,
        drawImpliedProb,
        awayImpliedProb,
        dc1XOdds,
        dc12Odds,
        dcX2Odds,
        dc1XImpliedProb,
        dcX2ImpliedProb,
        over15Odds,
        under15Odds,
        over15ImpliedProb,
        over25Odds,
        under25Odds,
        over25ImpliedProb,
        under25ImpliedProb,
        over35Odds,
        under35Odds,
        over35ImpliedProb,
        bttsYesOdds,
        bttsNoOdds,
        bttsYesImpliedProb,
        bttsNoImpliedProb,
        topCorrectScores: topCorrectScores.length > 0 ? topCorrectScores : undefined,
      };

      if (!options?.skipDbSave) {
        db.saveMatchOddsCache(cleanId, result);
      }

      return result;
    } catch {
      return null;
    } finally {
      if (timeout) {
        clearTimeout(timeout);
        timeout = null;
      }
    }
  }

  /**
   * Export methods matching gustavofariaa/FlashscoreScraping export formats
   */
  exportData(data: Record<string, FlashscoreScrapedMatch> | FlashscoreScrapedMatch[], format: 'json' | 'json-array'): string {
    const list = Array.isArray(data) ? data : Object.values(data);

    if (format === 'json') {
      const obj: Record<string, FlashscoreScrapedMatch> = {};
      list.forEach((m) => { obj[m.matchId] = m; });
      return JSON.stringify(obj, null, 2);
    }

    return JSON.stringify(list, null, 2);
  }

  /**
   * Scrapes real Head-to-Head (H2H) match history and recent matches directly from Flashscore detailed feed (df_hh_1_{id})
   */
  async getMatchHeadToHead(matchId: string, fixtureHomeTeam?: string, fixtureAwayTeam?: string): Promise<HeadToHeadMeasurement> {
    const cleanId = matchId.replace(/^fs_/, '').replace(/^hist_/, '').trim();
    
    // Check DB first (auto-upgrade from raw feed if cached with an older parserVersion)
    const existing = db.getPredictionMeasurement(cleanId);
    if (existing && (existing.parserVersion || 0) >= H2H_PARSER_VERSION) return existing;

    try {
      let feedText: string | null = null;
      const rawStored = db.getRawFeed(cleanId, true);
      if (rawStored && rawStored.rawText && (rawStored.rawText.includes('KB÷') || rawStored.rawText.includes('KC÷'))) {
        feedText = rawStored.rawText;
        loggerService.addLog({
          level: 'INFO',
          category: 'DATABASE',
          source: 'FlashscoreScraper',
          message: `Loaded raw H2H feed from local SQLite database for match ${cleanId}`,
        });
      }

      if (!feedText) {
        try {
          const fetched = await this.fetchFlashscoreFeed(`df_hh_1_${cleanId}`);
          if (fetched && (fetched.includes('KB÷') || fetched.includes('KC÷'))) {
            feedText = fetched;
            db.saveRawFeedData(cleanId, `df_hh_1_${cleanId}`, feedText);
            loggerService.addLog({
              level: 'INFO',
              category: 'SCRAPER',
              source: 'FlashscoreScraper',
              message: `Fetched fresh H2H feed from Flashscore network for match ${cleanId}`,
            });
          }
        } catch {
          // Continue to historical database fallback
        }
      }

      if (feedText) {
        const measurement = parseHeadToHeadFeedText(feedText, cleanId, fixtureHomeTeam, fixtureAwayTeam);
        if (measurement) {
          db.savePredictionMeasurement(cleanId, measurement);
          if (matchId && matchId !== cleanId) {
            db.savePredictionMeasurement(matchId, measurement);
          }
          db.saveH2HRecord(cleanId, measurement);

          loggerService.addLog({
            level: 'INFO',
            category: 'SCRAPER',
            source: 'FlashscoreScraper',
            message: `Scraped H2H for ${measurement.homeClub || fixtureHomeTeam} vs ${measurement.awayClub || fixtureAwayTeam}: ${measurement.matchesCount} meetings found`,
          });

          return measurement;
        }
      }
    } catch (err: any) {
      loggerService.addLog({
        level: 'WARN',
        category: 'SCRAPER',
        source: 'FlashscoreScraper',
        message: `H2H feed unavailable for match ${cleanId} (${fixtureHomeTeam || 'Home'} vs ${fixtureAwayTeam || 'Away'}) - using baseline head-to-head`,
      });
    }

    // Fallback: Calculate H2H & Recent Matches from DB historical matches if teams provided
    if (fixtureHomeTeam || fixtureAwayTeam) {
      const homeHist = (fixtureHomeTeam ? db.getTeamHistoricalMatches(fixtureHomeTeam, 20) : [])
        .slice()
        .sort((a, b) => normalizeDateStr(b.matchDate).localeCompare(normalizeDateStr(a.matchDate)));
      const awayHist = (fixtureAwayTeam ? db.getTeamHistoricalMatches(fixtureAwayTeam, 20) : [])
        .slice()
        .sort((a, b) => normalizeDateStr(b.matchDate).localeCompare(normalizeDateStr(a.matchDate)));

      const homeRecentMatches: TeamFormMatch[] = [];
      for (const m of homeHist) {
        const side = resolveTeamSide(fixtureHomeTeam, m.homeTeam, m.awayTeam);
        if (!side) continue;
        const isH = side === 'HOME';
        const gf = isH ? m.fthg : m.ftag;
        const ga = isH ? m.ftag : m.fthg;
        const opp = isH ? m.awayTeam : m.homeTeam;
        const res: 'W' | 'D' | 'L' = gf > ga ? 'W' : gf < ga ? 'L' : 'D';
        homeRecentMatches.push({
          date: normalizeDateStr(m.matchDate),
          opponent: opp,
          isHome: isH,
          goalsFor: gf,
          goalsAgainst: ga,
          result: res,
          competition: m.div,
        });
      }

      const awayRecentMatches: TeamFormMatch[] = [];
      for (const m of awayHist) {
        const side = resolveTeamSide(fixtureAwayTeam, m.homeTeam, m.awayTeam);
        if (!side) continue;
        const isH = side === 'HOME';
        const gf = isH ? m.fthg : m.ftag;
        const ga = isH ? m.ftag : m.fthg;
        const opp = isH ? m.awayTeam : m.homeTeam;
        const res: 'W' | 'D' | 'L' = gf > ga ? 'W' : gf < ga ? 'L' : 'D';
        awayRecentMatches.push({
          date: normalizeDateStr(m.matchDate),
          opponent: opp,
          isHome: isH,
          goalsFor: gf,
          goalsAgainst: ga,
          result: res,
          competition: m.div,
        });
      }

      const allHistorical = db.getAllHistoricalMatches(3000);
      const directH2H = allHistorical
        .filter((m) => resolveFixtureAlignment(fixtureHomeTeam, fixtureAwayTeam, m.homeTeam, m.awayTeam).matched)
        .sort((a, b) => normalizeDateStr(b.matchDate).localeCompare(normalizeDateStr(a.matchDate)));

      let homeWins = 0, draws = 0, awayWins = 0, homeGoalsTotal = 0, awayGoalsTotal = 0;
      const cappedH2H = directH2H.slice(0, 15);
      const recentH2H: HeadToHeadMatchRecord[] = cappedH2H.map((m) => {
        const { isHomeFixture } = resolveFixtureAlignment(fixtureHomeTeam, fixtureAwayTeam, m.homeTeam, m.awayTeam);
        const gHome = isHomeFixture ? m.fthg : m.ftag;
        const gAway = isHomeFixture ? m.ftag : m.fthg;
        homeGoalsTotal += gHome;
        awayGoalsTotal += gAway;
        if (gHome > gAway) homeWins++;
        else if (gAway > gHome) awayWins++;
        else draws++;

        return {
          date: normalizeDateStr(m.matchDate),
          homeTeam: m.homeTeam,
          awayTeam: m.awayTeam,
          score: `${m.fthg}-${m.ftag}`,
          winner: m.fthg > m.ftag ? 'HOME' : m.ftag > m.fthg ? 'AWAY' : 'DRAW',
          competition: m.div,
        };
      });

      const matchesCount = homeWins + draws + awayWins;
      const homeGoalsAvg = matchesCount > 0 ? Number((homeGoalsTotal / matchesCount).toFixed(2)) : 0;
      const awayGoalsAvg = matchesCount > 0 ? Number((awayGoalsTotal / matchesCount).toFixed(2)) : 0;
      const netWinDiff = homeWins - awayWins;
      const netGoalDiff = homeGoalsTotal - awayGoalsTotal;
      const swing = matchesCount > 0 ? (netWinDiff * 0.02 + (netGoalDiff / matchesCount) * 0.015) : 0;
      const h2hMultiplierHome = Number(Math.max(0.90, Math.min(1.15, 1.0 + swing)).toFixed(3));
      const h2hMultiplierAway = Number(Math.max(0.90, Math.min(1.15, 1.0 - swing)).toFixed(3));

      const fallbackMeasurement: HeadToHeadMeasurement = {
        parserVersion: H2H_PARSER_VERSION,
        matchesCount,
        homeWins,
        draws,
        awayWins,
        homeGoalsAvg,
        awayGoalsAvg,
        h2hMultiplierHome,
        h2hMultiplierAway,
        recentH2H,
        homeClub: fixtureHomeTeam,
        awayClub: fixtureAwayTeam,
        homeRecentMatches,
        awayRecentMatches,
      };

      if (matchesCount > 0 || homeRecentMatches.length > 0 || awayRecentMatches.length > 0) {
        db.savePredictionMeasurement(cleanId, fallbackMeasurement);
        if (matchId && matchId !== cleanId) {
          db.savePredictionMeasurement(matchId, fallbackMeasurement);
        }
        db.saveH2HRecord(cleanId, fallbackMeasurement);
      }
      return fallbackMeasurement;
    }

    // Zero encounters between teams in real records directly from Flashscore feed
    const cleanZeroH2H: HeadToHeadMeasurement = {
      parserVersion: H2H_PARSER_VERSION,
      matchesCount: 0,
      homeWins: 0,
      draws: 0,
      awayWins: 0,
      homeGoalsAvg: 0,
      awayGoalsAvg: 0,
      h2hMultiplierHome: 1.0,
      h2hMultiplierAway: 1.0,
      recentH2H: [],
      homeClub: fixtureHomeTeam,
      awayClub: fixtureAwayTeam,
      homeRecentMatches: [],
      awayRecentMatches: [],
    };
    return cleanZeroH2H;
  }

  /**
   * Prefetches and persists H2H raw feeds for upcoming matches during full sync
   */
  async prefetchH2HForUpcomingFixtures(upcoming: Fixture[], limit = 30): Promise<number> {
    let count = 0;
    const targetFixtures = upcoming.slice(0, limit);
    const batchSize = 5;
    for (let i = 0; i < targetFixtures.length; i += batchSize) {
      const slice = targetFixtures.slice(i, i + batchSize);
      const settled = await Promise.allSettled(
        slice.map(async (f) => {
          const cleanId = f.id.replace(/^fs_/, '').replace(/^hist_/, '').trim();
          if (!cleanId) return false;
          await this.getMatchHeadToHead(cleanId, f.homeTeam, f.awayTeam);
          return true;
        })
      );
      for (const r of settled) {
        if (r.status === 'fulfilled' && r.value) count++;
      }
    }
    return count;
  }

  /**
   * Prefetches and persists Flashscore pre-match market odds into SQLite (match_odds_cache & upcoming_fixtures)
   * during Full Sync, prioritizing popular competitions and imminent fixtures.
   */
  async prefetchOddsForUpcomingFixtures(
    upcoming: Fixture[],
    limit = 200,
    concurrency = 10
  ): Promise<number> {
    if (!upcoming || upcoming.length === 0) return 0;

    const existingOddsMap = db.getAllMatchOddsCache();

    // Hydrate any already-cached odds onto incoming fixtures first
    for (const f of upcoming) {
      const cleanId = f.id.replace(/^fs_/, '').replace(/^hist_/, '').trim();
      const cached = existingOddsMap.get(cleanId) || existingOddsMap.get(f.id);
      if (cached && !f.marketOdds) {
        f.marketOdds = cached;
      }
    }

    const candidates = upcoming
      .filter((f) => {
        if (f.status === 'FINISHED' || f.status === 'CANCELLED' || f.status === 'POSTPONED') return false;
        const cleanId = f.id.replace(/^fs_/, '').replace(/^hist_/, '').trim();
        return Boolean(cleanId) && !existingOddsMap.has(cleanId) && !existingOddsMap.has(f.id);
      })
      .sort((a, b) => {
        const pa = getLeaguePriority(a.league, a.leagueName);
        const pb = getLeaguePriority(b.league, b.leagueName);
        if (pa !== pb) return pb - pa;
        const da = `${a.matchDate} ${a.kickOffTime}`;
        const dbDate = `${b.matchDate} ${b.kickOffTime}`;
        return da.localeCompare(dbDate);
      })
      .slice(0, limit);

    if (candidates.length === 0) return existingOddsMap.size;

    let fetchedCount = 0;
    const savedBatch: Array<{ fixtureId: string; odds: ScrapedMarketOdds }> = [];

    for (let i = 0; i < candidates.length; i += concurrency) {
      const slice = candidates.slice(i, i + concurrency);
      const results = await Promise.all(
        slice.map(async (f) => {
          const cleanId = f.id.replace(/^fs_/, '').replace(/^hist_/, '').trim();
          const odds = await this.fetchMatchOdds(cleanId, {
            homeParticipantId: f.homeParticipantId,
            awayParticipantId: f.awayParticipantId,
            forceRefresh: true,
            skipDbSave: true,
          }).catch(() => null);
          return { fixture: f, cleanId, odds };
        })
      );

      for (const { fixture, cleanId, odds } of results) {
        if (odds) {
          fixture.marketOdds = odds;
          savedBatch.push({ fixtureId: cleanId, odds });
          fetchedCount++;
        }
      }
    }

    if (savedBatch.length > 0) {
      db.saveMatchOddsBatch(savedBatch);
    }

    loggerService.addLog({
      level: 'SUCCESS',
      category: 'SCRAPER',
      source: 'FlashscoreScraper',
      message: `Scraped & persisted Flashscore market odds for ${fetchedCount}/${candidates.length} upcoming fixtures into SQLite`,
      details: { fetchedCount, totalAttempted: candidates.length, totalCached: existingOddsMap.size + fetchedCount },
    });

    return fetchedCount;
  }

  /**
   * Parses recent match list for a specific club directly from scraper response
   */
  async getClubRecentMatches(clubName: string, matchId?: string): Promise<TeamFormMatch[]> {
    if (!clubName) return [];

    // 1. If matchId is provided, resolve true (homeTeam, awayTeam) pair first so cache is never poisoned with single-team orientation
    if (matchId) {
      const cleanId = matchId.replace(/^fs_/, '').replace(/^hist_/, '').trim();
      const stored =
        predictionsDb.getPredictionById(matchId) ||
        predictionsDb.getPredictionById(cleanId) ||
        db.getFixtureById(matchId) ||
        db.getFixtureById(cleanId);
      const h2h = await this.getMatchHeadToHead(cleanId, stored?.homeTeam, stored?.awayTeam);
      const side = resolveTeamSide(clubName, h2h.homeClub, h2h.awayClub);
      if (side === 'HOME' && h2h.homeRecentMatches && h2h.homeRecentMatches.length > 0) {
        return h2h.homeRecentMatches;
      }
      if (side === 'AWAY' && h2h.awayRecentMatches && h2h.awayRecentMatches.length > 0) {
        return h2h.awayRecentMatches;
      }
    }

    // 2. Check DB entries
    const allMeas = db.getAllPredictionMeasurements();
    for (const cached of allMeas.values()) {
      const side = resolveTeamSide(clubName, cached.homeClub, cached.awayClub);
      if (side === 'HOME' && cached.homeRecentMatches?.length) {
        return cached.homeRecentMatches;
      }
      if (side === 'AWAY' && cached.awayRecentMatches?.length) {
        return cached.awayRecentMatches;
      }
    }

    // 3. Find fixture involving this club from upcoming fixtures
    try {
      const fixtures = await this.getUpcomingFixtures();
      let bestMatch: { fixture: Fixture; side: 'HOME' | 'AWAY'; score: number } | null = null;
      for (const f of fixtures) {
        const homeScore = teamMatchScore(clubName, f.homeTeam);
        const awayScore = teamMatchScore(clubName, f.awayTeam);
        const maxScore = Math.max(homeScore, awayScore);
        if (maxScore > 0 && (!bestMatch || maxScore > bestMatch.score)) {
          bestMatch = {
            fixture: f,
            side: homeScore >= awayScore ? 'HOME' : 'AWAY',
            score: maxScore,
          };
        }
      }
      if (bestMatch && bestMatch.fixture.id) {
        const cleanId = bestMatch.fixture.id.replace(/^fs_/, '');
        const h2h = await this.getMatchHeadToHead(cleanId, bestMatch.fixture.homeTeam, bestMatch.fixture.awayTeam);
        if (bestMatch.side === 'HOME' && h2h.homeRecentMatches?.length) {
          return h2h.homeRecentMatches;
        }
        if (bestMatch.side === 'AWAY' && h2h.awayRecentMatches?.length) {
          return h2h.awayRecentMatches;
        }
      }
    } catch (err) {
      // Data not available - cleanly continue without terminal log
    }

    // 4. Return empty if not available in Flashscore scraper feeds
    return [];
  }

  /**
   * Parse Flashscore delimiter format into LeagueStandingEntry array
   */
  private parseStandingsFeed(feedText: string): LeagueStandingEntry[] {
    const entries: LeagueStandingEntry[] = [];
    const sections = feedText.split('~');

    for (const section of sections) {
      if (!section) continue;
      // Standings row indicator in Flashscore feed
      if (section.startsWith('TR÷') || section.includes('¬TR÷') || section.includes('¬TN÷')) {
        const parts = section.split('¬');
        const data: Record<string, string> = {};
        for (const p of parts) {
          const [k, v] = p.split('÷');
          if (k && v !== undefined) {
            data[k] = v;
          }
        }

        const teamName = data['TN'] || data['TI'] || data['AE'];
        const rank = parseInt(data['TR'] || data['RK'] || '0', 10);
        const played = parseInt(data['TP'] || data['MP'] || data['GP'] || '0', 10);
        const won = parseInt(data['TW'] || data['W'] || '0', 10);
        const drawn = parseInt(data['TD'] || data['D'] || '0', 10);
        const lost = parseInt(data['TL'] || data['L'] || '0', 10);

        // Goals parsing e.g. TG÷45:20 or separate GF/GA
        let goalsFor = 0;
        let goalsAgainst = 0;
        if (data['TG'] && data['TG'].includes(':')) {
          const [gf, ga] = data['TG'].split(':');
          goalsFor = parseInt(gf, 10) || 0;
          goalsAgainst = parseInt(ga, 10) || 0;
        } else {
          goalsFor = parseInt(data['GF'] || data['TG'] || '0', 10);
          goalsAgainst = parseInt(data['GA'] || data['TC'] || '0', 10);
        }

        const points = parseInt(data['PTS'] || data['PT'] || '0', 10);
        const badge = data['TB'] ? `${STATIC_IMAGE_BASE}${data['TB']}` : undefined;

        // Form string e.g. "W,D,W,L,W" or "WDWLW"
        let form: ('W' | 'D' | 'L')[] = [];
        const rawForm = data['FM'] || data['FR'] || '';
        if (rawForm) {
          form = rawForm
            .toUpperCase()
            .replace(/[^WDL]/g, '')
            .split('')
            .slice(-5) as ('W' | 'D' | 'L')[];
        }

        if (teamName && (played > 0 || points > 0 || rank > 0)) {
          entries.push({
            rank: rank || (entries.length + 1),
            teamId: data['TI'],
            teamName: teamName.trim(),
            badge,
            played,
            won,
            drawn,
            lost,
            goalsFor,
            goalsAgainst,
            goalDifference: goalsFor - goalsAgainst,
            points,
            form: form.length > 0 ? form : undefined,
          });
        }
      }
    }

    if (entries.length > 0) {
      entries.sort((a, b) => a.rank - b.rank);
      entries.forEach((e, i) => { e.rank = i + 1; });
    }

    return entries;
  }

  /**
   * Scrapes standings from Flashscore during fullsync process and saves to SQLite database table
   */
  async fetchAndSaveLeagueStandings(leagueCode: string): Promise<LeagueStandingTable | null> {
    const cleanCode = leagueCode.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    const urlMap: Record<string, { path: string; name: string; country: string }> = {
      'europe_champions_league': { path: '/football/europe/champions-league/standings/', name: 'UEFA Champions League', country: 'Europe' },
      'europe_champions_league_league_phase': { path: '/football/europe/champions-league/standings/', name: 'UEFA Champions League', country: 'Europe' },
      'europe_uefa_champions_league': { path: '/football/europe/champions-league/standings/', name: 'UEFA Champions League', country: 'Europe' },
      'ucl': { path: '/football/europe/champions-league/standings/', name: 'UEFA Champions League', country: 'Europe' },
      'europe_europa_league': { path: '/football/europe/europa-league/standings/', name: 'UEFA Europa League', country: 'Europe' },
      'europe_uefa_europa_league': { path: '/football/europe/europa-league/standings/', name: 'UEFA Europa League', country: 'Europe' },
      'europe_europa_league_league_phase': { path: '/football/europe/europa-league/standings/', name: 'UEFA Europa League', country: 'Europe' },
      'uel': { path: '/football/europe/europa-league/standings/', name: 'UEFA Europa League', country: 'Europe' },
      'europe_uefa_conference_league': { path: '/football/europe/conference-league/standings/', name: 'UEFA Conference League', country: 'Europe' },
      'europe_conference_league_league_phase': { path: '/football/europe/conference-league/standings/', name: 'UEFA Conference League', country: 'Europe' },
      'uecl': { path: '/football/europe/conference-league/standings/', name: 'UEFA Conference League', country: 'Europe' },
      'england_premier_league': { path: '/football/england/premier-league/standings/', name: 'English Premier League', country: 'England' },
      'e0': { path: '/football/england/premier-league/standings/', name: 'English Premier League', country: 'England' },
      'england_championship': { path: '/football/england/championship/standings/', name: 'English Championship', country: 'England' },
      'e1': { path: '/football/england/championship/standings/', name: 'English Championship', country: 'England' },
      'spain_la_liga': { path: '/football/spain/laliga/standings/', name: 'Spanish La Liga', country: 'Spain' },
      'sp1': { path: '/football/spain/laliga/standings/', name: 'Spanish La Liga', country: 'Spain' },
      'germany_bundesliga': { path: '/football/germany/bundesliga/standings/', name: 'German Bundesliga', country: 'Germany' },
      'd1': { path: '/football/germany/bundesliga/standings/', name: 'German Bundesliga', country: 'Germany' },
      'italy_serie_a': { path: '/football/italy/serie-a/standings/', name: 'Italian Serie A', country: 'Italy' },
      'i1': { path: '/football/italy/serie-a/standings/', name: 'Italian Serie A', country: 'Italy' },
      'france_ligue_1': { path: '/football/france/ligue-1/standings/', name: 'French Ligue 1', country: 'France' },
      'f1': { path: '/football/france/ligue-1/standings/', name: 'French Ligue 1', country: 'France' },
      'netherlands_eredivisie': { path: '/football/netherlands/eredivisie/standings/', name: 'Dutch Eredivisie', country: 'Netherlands' },
      'n1': { path: '/football/netherlands/eredivisie/standings/', name: 'Dutch Eredivisie', country: 'Netherlands' },
      'portugal_primeira_liga': { path: '/football/portugal/liga-portugal/standings/', name: 'Portuguese Primeira Liga', country: 'Portugal' },
      'p1': { path: '/football/portugal/liga-portugal/standings/', name: 'Portuguese Primeira Liga', country: 'Portugal' },
      'brazil_serie_a': { path: '/football/brazil/serie-a/standings/', name: 'Brazilian Série A', country: 'Brazil' },
      'bra': { path: '/football/brazil/serie-a/standings/', name: 'Brazilian Série A', country: 'Brazil' },
      'usa_major_league_soccer': { path: '/football/usa/mls/standings/', name: 'Major League Soccer', country: 'USA' },
      'mls': { path: '/football/usa/mls/standings/', name: 'Major League Soccer', country: 'USA' },
    };

    let target = urlMap[cleanCode];
    if (!target) {
      const parts = cleanCode.split('_');
      if (parts.length >= 2) {
        const country = parts[0];
        const leagueName = parts.slice(1).join('-');
        target = {
          path: `/football/${country}/${leagueName}/standings/`,
          name: leagueCode.replace(/_/g, ' '),
          country: country.charAt(0).toUpperCase() + country.slice(1),
        };
      } else {
        target = {
          path: `/football/${cleanCode.replace(/_/g, '-')}/standings/`,
          name: cleanCode.replace(/_/g, ' ').toUpperCase(),
          country: 'International',
        };
      }
    }

    let standingsTimeout: NodeJS.Timeout | null = null;
    try {
      const pageUrl = `https://www.flashscore.com${target.path}`;
      const controller = new AbortController();
      standingsTimeout = setTimeout(() => controller.abort(), 8000);

      const res = await fetch(pageUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        signal: controller.signal,
      });

      if (res.ok) {
        const html = await res.text();
        
        // 1. Try to extract direct 'standings' feed if available (Optimized On-Demand Method)
        const standingsMatch = html.match(/cjs\.initialFeeds\['standings'\]\s*=\s*\{\s*data:\s*[\`\"']([\s\S]*?)[\`\"']\s*\}/);
        if (standingsMatch && standingsMatch[1]) {
          const feedText = standingsMatch[1];
          const entries = this.parseStandingsFeed(feedText);
          if (entries.length > 0) {
            const table: LeagueStandingTable = {
              leagueCode: cleanCode,
              leagueName: target.name,
              country: target.country,
              season: getCurrentSeason(),
              updatedAt: new Date().toISOString(),
              source: 'FLASHSCORE_SCRAPED',
              table: entries,
            };
            db.saveLeagueStandings(table);
            return table;
          }
        }

        // 2. Fallback: Extract 'results' feed and calculate standings manually (Local Engine Method)
        const resultsMatch = html.match(/cjs\.initialFeeds\['results'\]\s*=\s*\{\s*data:\s*[\`\"']([\s\S]*?)[\`\"']\s*\}/);

        if (resultsMatch && resultsMatch[1]) {
          const feedText = resultsMatch[1];
          const sections = feedText.split('~');
          const parsedResults: Array<{
            ts: number;
            homeTeam: string;
            awayTeam: string;
            homeScore: number;
            awayScore: number;
            homeBadge?: string;
            awayBadge?: string;
          }> = [];
          const seenResultIds = new Set<string>();

          for (const s of sections) {
            if (!s.startsWith('AA÷')) continue;
            const parts = s.split('¬');
            const data: Record<string, string> = {};
            for (const p of parts) {
              const sepIdx = p.indexOf('÷');
              if (sepIdx > 0) data[p.slice(0, sepIdx)] = p.slice(sepIdx + 1);
            }

            if (data['AB'] !== '3' || data['AG'] === undefined || data['AH'] === undefined) continue;
            const resId = data['AA'];
            if (resId && seenResultIds.has(resId)) continue;
            if (resId) seenResultIds.add(resId);

            const homeTeam = (data['AE'] || '').trim();
            const awayTeam = (data['AF'] || '').trim();
            const homeScore = parseInt(data['AG'], 10);
            const awayScore = parseInt(data['AH'], 10);
            if (!homeTeam || !awayTeam || isNaN(homeScore) || isNaN(awayScore)) continue;

            const ts = parseInt(data['AD'] || '0', 10) || 0;
            const rawHomeBadge = data['OA'] || data['OAJ'];
            const rawAwayBadge = data['OB'];

            parsedResults.push({
              ts,
              homeTeam,
              awayTeam,
              homeScore,
              awayScore,
              homeBadge: rawHomeBadge ? `${STATIC_IMAGE_BASE}${rawHomeBadge}` : undefined,
              awayBadge: rawAwayBadge ? `${STATIC_IMAGE_BASE}${rawAwayBadge}` : undefined,
            });
          }

          // Sort strictly newest-first by timestamp so form[0..4] holds the 5 most recent matches
          parsedResults.sort((a, b) => b.ts - a.ts);

          const teamStats = new Map<string, {
            played: number;
            won: number;
            drawn: number;
            lost: number;
            goalsFor: number;
            goalsAgainst: number;
            points: number;
            form: ('W' | 'D' | 'L')[];
            badge?: string;
          }>();

          for (const r of parsedResults) {
            if (!teamStats.has(r.homeTeam)) {
              teamStats.set(r.homeTeam, {
                played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0, points: 0, form: [],
                badge: r.homeBadge,
              });
            }
            if (!teamStats.has(r.awayTeam)) {
              teamStats.set(r.awayTeam, {
                played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0, points: 0, form: [],
                badge: r.awayBadge,
              });
            }

            const h = teamStats.get(r.homeTeam)!;
            const a = teamStats.get(r.awayTeam)!;
            if (!h.badge && r.homeBadge) h.badge = r.homeBadge;
            if (!a.badge && r.awayBadge) a.badge = r.awayBadge;

            h.played++; a.played++;
            h.goalsFor += r.homeScore; h.goalsAgainst += r.awayScore;
            a.goalsFor += r.awayScore; a.goalsAgainst += r.homeScore;

            if (r.homeScore > r.awayScore) {
              h.won++; h.points += 3; h.form.push('W');
              a.lost++; a.form.push('L');
            } else if (r.homeScore < r.awayScore) {
              a.won++; a.points += 3; a.form.push('W');
              h.lost++; h.form.push('L');
            } else {
              h.drawn++; h.points += 1; h.form.push('D');
              a.drawn++; a.points += 1; a.form.push('D');
            }
          }

          if (teamStats.size > 0) {
            const entries: LeagueStandingEntry[] = Array.from(teamStats.entries()).map(([teamName, s]) => ({
              rank: 1,
              teamName,
              badge: s.badge,
              played: s.played,
              won: s.won,
              drawn: s.drawn,
              lost: s.lost,
              goalsFor: s.goalsFor,
              goalsAgainst: s.goalsAgainst,
              goalDifference: s.goalsFor - s.goalsAgainst,
              points: s.points,
              form: (s.form.slice(0, 5) as ('W' | 'D' | 'L')[]) || undefined,
            }));

            entries.sort((a, b) => {
              if (b.points !== a.points) return b.points - a.points;
              if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
              if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
              return a.teamName.localeCompare(b.teamName);
            });

            entries.forEach((e, idx) => {
              e.rank = idx + 1;
            });

            const liveTable: LeagueStandingTable = {
              leagueCode: cleanCode,
              leagueName: target.name,
              country: target.country,
              season: getCurrentSeason(),
              updatedAt: new Date().toISOString(),
              source: 'FLASHSCORE_SCRAPED',
              table: entries,
            };

            db.saveLeagueStandings(liveTable);
            return liveTable;
          }
        }
      }
    } catch (err) {
      // Catch cleanly
    } finally {
      if (standingsTimeout) {
        clearTimeout(standingsTimeout);
        standingsTimeout = null;
      }
    }

    return null;
  }

  /**
   * Retrieves league standings table strictly 100% from SQLite database saved data
   */
  async getLeagueStandings(leagueCode: string, _tournamentSlug?: string): Promise<LeagueStandingTable> {
    const cleanCode = leagueCode.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    // 2. Query 100% strictly from SQLite database table
    const dbStandings = db.getLeagueStandings(cleanCode);
    if (dbStandings) {
      const tableData = Array.isArray(dbStandings.table)
        ? dbStandings.table
        : Array.isArray(dbStandings.standings)
        ? dbStandings.standings
        : [];

      if (tableData.length > 0) {
        const formatted: LeagueStandingTable = {
          leagueCode: cleanCode,
          leagueName: dbStandings.leagueName || cleanCode.replace(/_/g, ' ').toUpperCase(),
          country: dbStandings.country || 'LEAGUE',
          season: dbStandings.season || getCurrentSeason(),
          updatedAt: dbStandings.updatedAt || new Date().toISOString(),
          source: 'FLASHSCORE_SCRAPED',
          table: tableData,
        };
        return formatted;
      }
    }

    // 3. Fallback: Empty table structure if not yet populated into SQLite table via fullsync
    const emptyTable: LeagueStandingTable = {
      leagueCode: cleanCode,
      leagueName: cleanCode.replace(/_/g, ' ').toUpperCase(),
      country: cleanCode.split('_')[0]?.toUpperCase() || 'LEAGUE',
      season: getCurrentSeason(),
      updatedAt: new Date().toISOString(),
      source: 'FLASHSCORE_SCRAPED',
      table: [],
    };
    return emptyTable;
  }
  public getProviderStatus(): ProviderStatus {
    return {
      id: 'FLASHSCORE',
      name: 'Flashscore Live Scraper',
      type: 'SCRAPER',
      status: 'ONLINE',
      latencyMs: 0,
      description: 'Direct FlashscoreScraping engine extracting live match results, in-play statistics, worldwide fixtures, and results directly from Flashscore.',
      features: ['Direct Flashscore Feed Scraper', 'Real-Time In-Play Scores', '50+ Worldwide Leagues & Cups', 'Live Statistics & Results', 'Instant SQLite Sync'],
    };
  }
}

export const flashscoreScraperService = new FlashscoreScraperService();
