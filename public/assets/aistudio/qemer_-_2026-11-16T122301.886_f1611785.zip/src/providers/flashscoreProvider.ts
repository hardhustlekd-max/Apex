import { APIProvider, LiveScore } from './types.js';
import { Fixture, LeagueStandingTable } from '../core/types.js';
import { flashscoreScraperService } from '../services/flashscoreScraperService.js';

export class FlashscoreProvider implements APIProvider {
  id = 'FLASHSCORE' as const;
  name = 'Flashscore Live Scraper';
  type = 'SCRAPER' as const;
  description = 'Direct FlashscoreScraping engine extracting live match results, in-play statistics, worldwide fixtures, and results directly from Flashscore.';
  features = [
    'Direct Flashscore Scraper Engine',
    'Real-Time Live Scores & Minutes',
    'Full Worldwide Coverage (50+ Leagues & Cups)',
    'Head-to-Head Statistics & Results',
    'Automated SQLite Persistence',
  ];

  async getUpcomingFixtures(date?: string): Promise<Fixture[]> {
    return flashscoreScraperService.getUpcomingFixtures(date);
  }

  async getLiveScores(): Promise<LiveScore[]> {
    return flashscoreScraperService.getLiveScores();
  }

  async syncHistoricalData(daysBack = 7, shouldClear = true): Promise<{ success: boolean; matchesCount: number; message: string }> {
    return flashscoreScraperService.syncHistoricalData(daysBack, shouldClear);
  }

  async getLeagueStandings(league: string): Promise<LeagueStandingTable | null> {
    return flashscoreScraperService.getLeagueStandings(league);
  }
}
