import { FileTypes } from "../../constants/index.js";

export const parseArguments = () => {
  const args = process.argv.slice(2);
  const options = {
    country: null,
    league: null,
    fileType: null,
    concurrency: 10,
    saveInterval: 10,
    headless: true,
  };

  args.forEach((arg) => {
    if (arg.startsWith("country=")) options.country = arg.split("=")[1];
    if (arg.startsWith("league=")) options.league = arg.split("=")[1];
    if (arg.startsWith("fileType=")) options.fileType = arg.split("=")[1];
    if (arg.startsWith("concurrency="))
      options.concurrency = Number(arg.split("=")[1]);
    if (arg.startsWith("saveInterval="))
      options.saveInterval = Number(arg.split("=")[1]);
    if (arg.startsWith("headless="))
      options.headless = arg.split("=")[1] !== "false";
    if (arg === "--no-headless") options.headless = false;
    if (arg === "--headless") options.headless = true;
  });

  if (options.fileType) {
    const userInput = options.fileType;
    const matchedType = Object.values(FileTypes).find(
      (type) => type.argument === userInput
    );

    if (!matchedType) {
      const acceptedTypes = Object.values(FileTypes)
        .map((type) => `"${type.argument}"`)
        .join(", ");
      throw Error(
        `❌ Invalid fileType: "${userInput}"\n` +
          `Accepted file types are: ${acceptedTypes}`
      );
    }

    options.fileType = matchedType;
  }

  if (options.league && !options.country) {
    throw Error(
      `❌ Missing required argument: country=<country-name>\n` +
        `You provided a league "${options.league}" but did not specify a country\n` +
        `Usage example: country=<country-name> league=<league-name>`
    );
  }

  return options;
};
