# Apex Live Score — Core UI System, Component Library & Design Guidelines

**System ID:** `APEX-UI-CORE-v2.0`  
**Architecture:** Responsive Mobile-First Touch + Desktop Master-Detail Web App  
**Visual Paradigm:** Borderless Editorial Sports Telemetry (Tonal Elevation + Tabular Precision)  
**Target Breakpoints:** Mobile (`375px–639px`), Tablet (`640px–1023px`), Desktop (`1024px–1440px+`)

---

## 1. Preserved UI Structural Blueprint (Non-Negotiable Layout Contract)

Every refactor or feature addition MUST preserve the application's exact multi-viewport structural skeleton:

### 1.1 Application Shell
1. **Top Sticky App Header (`h-12` / `48px`, `sticky top-0 z-30`)**
   - Strictly single-row, 3-zone layout inside `max-w-7xl mx-auto`:
     - **Left Zone:** Compact brand mark (`A` monogram badge + `Apex Live Score` wordmark, `whitespace-nowrap shrink-0`).
     - **Center Zone (`hidden sm:flex`):** Contextual view title (`Today's Matches`).
     - **Right Zone:** Single primary utility trigger (`Settings` gear icon button, `#open-settings-modal-btn`).
2. **Desktop Left Navigation Rail (`w-60` / `240px`, `hidden lg:flex flex-col sticky top-12 h-[calc(100vh-3rem)]`)**
   - **Top Lockup:** Secondary engine identity (`L` mark + `Live Score Engine` / `Poisson Projections`).
   - **Primary Navigation:** 4 core destinations (`Predictions & Live`, `Accumulators`, `Standings Table`, `Prediction History`) with optional live/count indicator.
   - **Quick Competitions Rail:** Curated top-6 leagues + `All Matches`, plus `All >` modal trigger (`LeagueSelectorModal`).
   - **Footer Utility Strip:** Live engine status indicator + 3 quick action buttons (`Light/Dark` toggle, `Terminal`, `Settings`).
3. **Mobile Bottom Navigation Dock (`fixed bottom-0 z-40 lg:hidden`)**
   - Thumb-zone 4-tab bar (`FIXTURES`, `ACCAS`, `STANDINGS`, `HISTORY`) with safe-area inset padding and active accent dot indicator.
4. **Main Content Canvas (`main max-w-7xl mx-auto pb-16 lg:pb-6`)**
   - `FIXTURES`: **12-column Master-Detail Split** on `lg:+` (`col-span-7` Master Feed + `col-span-5` sticky Inspector `<MatchDetailView isPanel />`), collapsing to single-column feed + slide-up `<MatchDetailModal />` on `< lg`.
   - `ACCAS`: Centered `max-w-4xl mx-auto`.
   - `STANDINGS`: Centered `max-w-5xl mx-auto`.
   - `HISTORY`: Centered `max-w-4xl mx-auto`.

### 1.2 Fixtures Feed Flow (`FixturesList`)
1. **7-Day Horizontal Selector Bar (`grid-cols-7`)**
2. **Scope Sub-Tabs (`Upcoming` | `Live` | `History`) + `Filters` Button**
3. **Conditional Active Filter Chips Strip**
4. **Match List (`SimplifiedPredictionsWireframe` grouped league tables or `FixtureCard` 2-col grid)**
5. **Pagination Bar**

### 1.3 Match Detail Inspector / Modal Flow (`MatchDetailModal`)
1. **Sheet/Modal Header** (Drag handle on mobile modal, League/Stage, Close button)
2. **Compact Hero Scoreboard** (Home + Win% | Score/VS + Status | Away + Win%)
3. **4-Tab Switcher** (`Overview` | `H2H` | `Teams` | `Preds`)
4. **Structured Tab Panels**

---

## 2. Token Architecture & Visual Rules
- **Borderless Tonal Hierarchy:** `--bg-primary` (Canvas) -> `--bg-card` (Container) -> `--bg-card-elevated` (Elevated Sub-surface) -> `--bg-subtle` (Inputs, Interactive fills).
- **Typography:** `Plus Jakarta Sans` (UI Display & Body) + `JetBrains Mono` (`tabular-nums` on all scores, times, odds, and probabilities).
- **Dual-Mode 4-Palette System:** `opta-emerald`, `champions-crimson`, `ballon-gold`, `volt-lime` across Light and Dark modes.
- **Accessibility:** `focus-visible:ring-2 focus-visible:ring-theme-accent`, `>= 44px` mobile touch hitboxes, `prefers-reduced-motion` support, Zero-Broken-Image `<TeamAvatar />` fallback.

---

## 3. Core UI Component System (`src/components/ui/`)
`Button`, `Card`, `Modal`, `SegmentedTabs`, `Input`, `Select`, `Badge`, `StatTile`, `TeamAvatar`, `ProgressBar`, `LoadingState`, `EmptyState`, `SectionHeader`, `PaginationBar`, `Toast`.
