# Analysis Plan: Low Prediction Accuracy (<10%) in Historical Evaluation

## 1. Executive Summary & Problem Diagnosis
When evaluating historical predictions against actual match outcomes over the last 50+ finished matches, the model accuracy is reporting abnormally low (~10%). A robust prediction engine operating on Poisson/Dixon-Coles models combined with proper data alignment should achieve baseline 1X2 outcome accuracy between 45% and 55%. 

The root cause of ~10% accuracy points to several distinct failure modes:
1. **Selection Mismatch**: The evaluation logic in `PredictionHistoryView.tsx` checks `f.mostLikelyOutcome` or fallback `HOME_WIN` against actual match results. If stored predictions lack properly populated `mostLikelyOutcome` or fallback to `HOME_WIN` blindly, accuracy collapses.
2. **Data Type / Outcome Evaluation Disconnect**: The `evaluatePrediction` function checks market keys (`HOME_WIN`, `DRAW`, `AWAY_WIN`, `OVER_25`, etc.). If `mostLikelyOutcome.marketKey` is evaluated instead of checking the actual 1X2 match outcome when evaluating 1X2 bets, or if goals markets are checked incorrectly against 1X2 results, accuracy drops.
3. **Mock vs Real Prediction Storing**: When historical matches are migrated or scraped without a full Poisson evaluation (e.g. mock fallback predictions with fixed 45% home win probabilities), the prediction does not match the actual statistical strengths of the teams.
4. **Team Name Normalization Discrepancies**: Historical match team names from CSV datasets versus Flashscore scraped team names might not align, causing the model to default to generic or flat expected goals ($\lambda = 1.0, \mu = 1.0$).

---

## 2. Step-by-Step Analytical Plan

### Step 1: Inspect the Evaluation Logic (`PredictionHistoryView.tsx`)
- Review how `evaluatePrediction` extracts `marketKey` and `predictedLabel`.
- Check whether it correctly evaluates 1X2 outcomes (`HOME_WIN`, `DRAW`, `AWAY_WIN`) or if it misinterprets total goals/BTTS markets as 1X2.

### Step 2: Verify Prediction Generation for Historical Matches (`fixturesRouter.ts` & `predictionsDb.ts`)
- Check how historical matches are saved into `historical_predictions`.
- Verify whether historical matches actually run through `ServerEngine.predictFixtureUnified(...)` before storage, or if they are stored with placeholder/mock predictions (`homeWinProb: 0.45`, etc.).

### Step 3: Audit Poisson / Dixon-Coles Probabilities (`poisson.ts`)
- Verify that `homeWinProb`, `drawProb`, and `awayWinProb` sum to 1.0 and accurately reflect team strength differentials.
- Check if home advantage or form decay rate causes extreme bias (e.g. always picking home win).

---

## 3. Corrective Implementation Steps (Actionable Fixes)
1. **Fix `evaluatePrediction` in `PredictionHistoryView.tsx`**:
   - Ensure the evaluation strictly checks the 1X2 outcome (`HOME_WIN`, `DRAW`, `AWAY_WIN`) against actual match result (`hG > aG`, `hG === aG`, `hG < aG`) or correctly evaluates the specific market key stored in `mostLikelyOutcome.marketKey`.
2. **Backfill Real Predictions for Historical Matches**:
   - Update `fixturesRouter.ts` (`/history` route) and `providersRouter.ts` so that any historical match being saved to `historical_predictions` runs through `ServerEngine.predictFixtureUnified(...)` using historical universe data rather than storing flat mock predictions.
3. **Verify Accuracy Metrics**:
   - Re-run `compile_applet` and test evaluation accuracy.
