# Team Data Swapping — Root-Cause Review & Fix Plan

A deep audit of the scraper, parser, SQLite database, prediction engine, and match detail views uncovered **four distinct causes** of swapped or cross-contaminated team data across matches (including live examples in SQLite where favorites and underdogs were completely inverted).

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Reviewing and confirming this plan will trigger fixes across feed parsing, team-name matching, odds participant anchoring, UI alignment, and a one-time rebuild/cleanup of affected cached measurements and predictions in SQLite.

- **Strict Category Isolation (Recommended)**: Prevent senior clubs/national teams from matching Youth (`U17`–`U23`), Women (`W` / `Women`), or Reserve (`B` / `II`) squads during historical form lookups.
- **No Unmatched Default-to-Home Fallback (Recommended)**: Unresolved team-side lookups (`null`) will never default to `HOME`; unrecognized rows will be skipped or resolved strictly against the section header club.
- **UI Defensive Alignment (Recommended)**: Even when viewing older cached data, the UI will verify team identity alignment before displaying Home vs Away form, goals, recent matches, and H2H win counts.

---

## 1. Root Causes Found (Verified Against Live Data & SQLite)

### Cause A — Youth / Women / Reserve & Short-Substring Contamination
- **What Happens**: A senior team's strength, xG, and recent form are populated with matches from a U18/U19/U20/U21/U23/Women team or an unrelated club sharing a 3-letter substring.
- **Why**:
  1. The team-matching normalizer explicitly strips `U19`, `U20`, `U21`, `U23`, `Women`, and `W` as generic affixes, scoring `"Sweden"` vs `"Sweden U19"` or `"Newcastle Utd W"` vs `"Newcastle Utd U21"` at **800/1000** (strong match).
  2. When a team has fewer than 5 exact historical matches, the SQLite lookup falls back to an unfiltered `LIKE '%coreToken%'` query, and substring matching triggers on any 3+ character match.
- **Verified Live SQLite Evidence** (`78` of `1,701` analyzed fixtures affected):
  - **Sweden vs Bosnia & Herzegovina**: Odds have Sweden as `1.44` favorite (`~63%`), but the engine predicted **Sweden 15.9% vs Bosnia 69.0%** because Sweden pulled **Sweden U18 / U19** (1–2 loss to Germany U19) while Bosnia pulled **Bosnia U19 / U21** (wins vs Georgia U19 & Montenegro U21).
  - **Sunderland W vs Newcastle Utd W**: `Newcastle Utd W` pulled `Newcastle Utd U21` matches (`Peterborough U21`).
  - **Bra vs Gozzano**: `"Bra"` matched `"Brazil U20"`.
  - **Schio vs LME**: `"LME"` matched `"Palmeiras U20"` (substring `lme`).
  - **Nissa vs Enna**: `"Enna"` matched `"First Vienna W"` (substring `enna`).

### Cause B — H2H Feed Header Poisoning & `null !== 'AWAY'` Flip
- **What Happens**: Away recent matches are flipped into Home losses/wins (with `goalsFor`, `goalsAgainst`, `isHome`, and `opponent` inverted) and saved into the H2H cache for subsequent views.
- **Why**:
  1. Club-level recent-match lookups pass only one team name into the H2H parser (`fixtureHomeTeam = clubName`, `fixtureAwayTeam = undefined`).
  2. Inside the H2H feed parser, `homeClubName` is pre-populated with that single club name before scanning sections. When the feed's first `Last matches:` block actually belongs to the *other* club, the header assigns `HOME_RECENT` to that block without updating `homeClubName`.
  3. Each match row inside `HOME_RECENT` then checks `resolveTeamSide(target, rawHome, rawAway)` where `target` is the wrong club. That returns `null`, and the check `side !== 'AWAY'` evaluates `null !== 'AWAY'` → **`true`**, silently treating away/unrelated games as Home fixtures and flipping goals and opponents.
  4. The same `resolveTeamSide(...) !== 'AWAY'` pattern exists in several fallback loops inside the prediction engine and scraper.

### Cause C — UI Display Ignores `h2h.homeClub` / `h2h.awayClub` Alignment
- **What Happens**: In the Match Detail modal's **Teams** and **H2H** tabs, Home and Away form guides, total goals, recent match lists, and H2H win/goal-average tiles can swap sides.
- **Why**:
  - Although an internal memo (`_h2hTrends`) checks whether `h2h.homeClub` matches `fixture.homeTeam` vs `fixture.awayTeam`, the actual rendered lists (`homeRecentMatchesList`, `awayRecentMatchesList`, `homeGoalsScored/Conceded`, `awayGoalsScored/Conceded`) and the H2H `StatTile` metrics read `h2h.homeRecentMatches`, `h2h.homeWins`, and `h2h.homeGoalsAvg` blindly without checking team alignment.

### Cause D — Unanchored GraphQL Participant IDs for Pre-Match Odds
- **What Happens**: Home (`1` / `1X`) and Away (`2` / `X2`) odds risk swapping when a match's participant IDs (`JA` / `JB`) aren't present on the fixture object.
- **Why**:
  - `upcoming_fixtures` and `predictions` do not persist `homeParticipantId` / `awayParticipantId`, so on-demand match detail fetches always pass `undefined`.
  - The odds fetcher falls back to inferring `[homePid, awayPid]` positionally from the GraphQL array order. Flashscore's GraphQL endpoint already reverses participant order in some markets (e.g. Asian/European Handicap arrays return `[awayPid, homePid]`), so relying purely on positional order when `JA`/`JB` are stored in the raw daily feed is fragile.

---

## 2. User Experience & Data Flow Integrity

```
┌───────────────────────────┐
│  Flashscore Daily / H2H   │  (Authoritative AE/AF Teams, JA/JB PIDs, KB Headers)
└─────────────┬─────────────┘
              │
              ▼
┌───────────────────────────┐
│  Strict Identity Layer    │  1. Enforce Category Tags (Senior vs U18-U23 vs W vs B/II)
│                           │  2. Anchor Recent Matches to KB Header Club First
│                           │  3. Eliminate `null !== 'AWAY'` Defaulting
│                           │  4. Resolve JA/JB PIDs from Raw Feed Before Odds Parsing
└─────────────┬─────────────┘
              │
              ▼
┌───────────────────────────┐
│   SQLite + Dixon-Coles    │  Clean Team Stats, Elo, xG, H2H, & 1X2 Probabilities
└─────────────┬─────────────┘
              │
              ▼
┌───────────────────────────┐
│  Match Detail UI Guard    │  Verify `resolveFixtureAlignment(fixture, h2h)` before
│                           │  rendering Teams Form, Recent Matches, & H2H Summary Tiles
└───────────────────────────┘
```

---

## 3. Key Technical Decisions & Trade-Offs

1. **Category-Aware Team Matching**:
   - *Chosen Approach*: Extract squad category tokens (`U17`–`U23`, `W`/`WOMEN`, `B`/`II`) separately before normalizing club names; require exact category compatibility (or strict zero-mismatch) and disallow blind 3-char substring matches on unrelated words.
   - *Why*: Eliminates youth/women/reserve cross-contamination (`Sweden` vs `Sweden U19`, `Bra` vs `Brazil U20`) while preserving legitimate name variations like `Mlada Boleslav (Cze)` ↔ `Mlada Boleslav`.
2. **Header-First H2H Parsing**:
   - *Chosen Approach*: Determine each recent-match section's perspective using the club explicitly named on the `KB÷Last matches: <Club>` header first, map sections to `fixtureHomeTeam` / `fixtureAwayTeam` via `resolveFixtureAlignment`, and skip any row where `resolveTeamSide` returns `null`.
   - *Why*: Prevents single-club H2H calls from ever inverting scores or poisoning the shared cache.
3. **Participant ID Anchoring for Odds**:
   - *Chosen Approach*: Extract `JA` (Home PID) and `JB` (Away PID) from stored raw daily feeds whenever `options.homeParticipantId` / `options.awayParticipantId` are missing before parsing GraphQL odds.
   - *Why*: Guarantees `1` (`homeOdds`) and `2` (`awayOdds`) always bind to Flashscore's authoritative home/away IDs without requiring a breaking DB schema migration.

---

## 4. Implementation & Verification Plan

1. **Harden Team Matching & H2H Feed Parsing**:
   - Separate squad-category detection (`U17`–`U23`, `W`/`WOMEN`, `B`/`II`) from club-prefix stripping so mismatched categories always score `0`.
   - Require whole-token alignment for short club abbreviations (`Bra`, `LME`, `Enna`) instead of arbitrary 3-character substring hits.
   - Fix `parseHeadToHeadFeedText` so `HOME_RECENT` and `AWAY_RECENT` resolve match orientation against each section's `KB÷Last matches:` club name, align cleanly against `(fixtureHomeTeam, fixtureAwayTeam)` when both are known, and skip rows with `null` side resolution instead of defaulting `isH = true`.
2. **Harden Historical DB Lookup & Prediction Loops**:
   - Filter `LIKE` fallback candidates in `FootballDB.getTeamHistoricalMatches` through `teamMatchScore(...) > 0` so unrelated teams/youth squads are rejected before leaving the DB layer.
   - Replace `resolveTeamSide(...) !== 'AWAY'` in prediction and fallback loops so `null` matches are never forced to Home.
3. **Anchor GraphQL Odds Participant IDs & Fix Club-Recent Lookup**:
   - Resolve `JA` / `JB` participant IDs from the raw daily feed in SQLite if missing when `fetchMatchOdds` runs.
   - Fix `getClubRecentMatches` so it resolves the fixture's true `(homeTeam, awayTeam)` pair before calling `getMatchHeadToHead` (preventing single-team cache poisoning).
4. **Defensive UI Alignment in Match Detail View**:
   - Apply `resolveFixtureAlignment` / `isHomeClubMatchingHomeFixture` to `homeRecentMatchesList`, `awayRecentMatchesList`, `homeRecentFormList`, `awayRecentFormList`, `homeGoalsScored/Conceded`, `awayGoalsScored/Conceded`, and H2H summary tiles (`homeWins`, `awayWins`, `homeGoalsAvg`, `awayGoalsAvg`, `h2hMultiplierHome`, `h2hMultiplierAway`), while removing the dead `_h2hTrends` memo.
5. **Rebuild Affected Cache & Verify**:
   - Re-evaluate/recalculate affected cached H2H records and fixtures in SQLite (clearing only contaminated entries, preserving all scraped datasets), run `compile_applet` + `lint_applet`, and run an automated verification check confirming zero category mismatches and zero inverted H2H/odds records across all fixtures.
